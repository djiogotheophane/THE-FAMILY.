import { MenuItem, UserReview, GalleryItem } from './types';

// Path to our custom premium AI-generated hero background
export const HERO_BACKGROUND = '/src/assets/images/the_family_hero_1780444735211.png';

// Premium high-res curation of Thai assets on Unsplash
export const PHOTO_PLACEHOLDERS = {
  padThai: 'https://images.unsplash.com/photo-1626804475315-7798725841fe?auto=format&fit=crop&q=80&w=800',
  tomYum: 'https://images.unsplash.com/photo-1548943487-a2e4e43b4853?auto=format&fit=crop&q=80&w=800',
  greenCurry: 'https://images.unsplash.com/photo-1455619452474-d2be8b1e70cd?auto=format&fit=crop&q=80&w=800',
  redCurry: 'https://images.unsplash.com/photo-1601050690597-df056fb4ce78?auto=format&fit=crop&q=80&w=800',
  springRolls: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&q=80&w=800',
  somTam: 'https://images.unsplash.com/photo-1617093727343-374698b1b08d?auto=format&fit=crop&q=80&w=800',
  spicySalad: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?auto=format&fit=crop&q=80&w=800',
  padKrapow: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&q=80&w=800',
  cashewChicken: 'https://images.unsplash.com/photo-1525755662778-989d0524087e?auto=format&fit=crop&q=80&w=800',
  fryRice: 'https://images.unsplash.com/photo-1603133872878-684f208fb84b?auto=format&fit=crop&q=80&w=800',
  seafood: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&q=80&w=800',
  mangoSticky: 'https://images.unsplash.com/photo-1534422298391-e4f8c172dddb?auto=format&fit=crop&q=80&w=800', // Mango sticky rich/sweet
  thaiTea: 'https://images.unsplash.com/photo-1576092768241-dec231879fc3?auto=format&fit=crop&q=80&w=800',
  fruits: 'https://images.unsplash.com/photo-1498837167922-ddd27525d352?auto=format&fit=crop&q=80&w=800',
  restaurantInterior: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1200',
  bangkokNight: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?auto=format&fit=crop&q=80&w=1200',
  thaiTemple: 'https://images.unsplash.com/photo-1528127269322-539801943592?auto=format&fit=crop&q=80&w=1200',
  thaiMarket: 'https://images.unsplash.com/photo-1569154941061-e231b4725ef1?auto=format&fit=crop&q=80&w=1200',
  teamCocktail: 'https://images.unsplash.com/photo-1552566626-52f8b828add9?auto=format&fit=crop&q=80&w=800'
};

export const MENU_ITEMS: MenuItem[] = [
  // ENTRIES (STARTERS)
  {
    id: 's1',
    name: 'Rouleaux de printemps thaïlandais',
    englishName: 'Thai Crispy Spring Rolls (Paw Pia Tod)',
    description: 'Délicats rouleaux croustillants dorés garnis de légumes frais émincés, de vermicelles et servis avec notre sauce aigre-douce maison.',
    price: 180,
    category: 'starters',
    image: PHOTO_PLACEHOLDERS.springRolls,
    spicyLevel: 0,
    tags: ['vegetarian', 'vegan']
  },
  {
    id: 's2',
    name: 'Soupe Tom Yum Shrimp',
    englishName: 'Tom Yum Goong',
    description: 'La célèbre soupe traditionnelle thaïlandaise épicée et parfumée aux herbes fraîches (citronnelle, galanga, feuilles de kaffir), champignons et crevettes tigrées.',
    price: 250,
    category: 'starters',
    image: PHOTO_PLACEHOLDERS.tomYum,
    spicyLevel: 3,
    tags: ['spicy', 'signature']
  },
  {
    id: 's3',
    name: 'Som Tam',
    englishName: 'Green Papaya Salad',
    description: 'Salade de papaye verte pilée au mortier traditionnelle avec piments frais, ail, tomates cerises, haricots serpent, cacahuètes grillées et sauce citronnée équilibrée.',
    price: 190,
    category: 'starters',
    image: PHOTO_PLACEHOLDERS.somTam,
    spicyLevel: 2,
    tags: ['spicy', 'gluten-free', 'signature']
  },
  {
    id: 's4',
    name: 'Salade thaïlandaise épicée',
    englishName: 'Yum Salat Thai',
    description: 'Mélange rafraîchissant de légumes de saison croquants, de coriandre, d’échalotes, relevé d’une vinaigrette au piment doux et au jus de citron vert.',
    price: 170,
    category: 'starters',
    image: PHOTO_PLACEHOLDERS.spicySalad,
    spicyLevel: 1,
    tags: ['vegetarian']
  },

  // MAINS (PLATS PRINCIPAUX)
  {
    id: 'm1',
    name: 'Pad Thai The Family',
    englishName: 'Authentic Pad Thai',
    description: 'Le joyau national : nouilles de riz sautées au wok avec du tofu ferme, des œufs, des germes de soja, de la ciboulette thaïlandaise, notre pâte de tamarin maison, garnies de cacahuètes pilées et citron vert.',
    price: 280,
    category: 'mains',
    image: PHOTO_PLACEHOLDERS.padThai,
    spicyLevel: 0,
    tags: ['signature', 'best-seller']
  },
  {
    id: 'm2',
    name: 'Curry Vert Thaï',
    englishName: 'Gaeng Keow Wan',
    description: 'Curry onctueux et parfumé au lait de coco fait maison, à la pâte de piments verts frais, mini-aubergines thaïes, feuilles de basilic doux et bambou tendre.',
    price: 310,
    category: 'mains',
    image: PHOTO_PLACEHOLDERS.greenCurry,
    spicyLevel: 2,
    tags: ['spicy', 'signature']
  },
  {
    id: 'm3',
    name: 'Curry Rouge Thaï',
    englishName: 'Gaeng Dang',
    description: 'Plat riche, piquant et délicatement sucré aux piments rouges séchés, lait de coco crémeux, pousses de bambou et basilic sacré.',
    price: 310,
    category: 'mains',
    image: PHOTO_PLACEHOLDERS.redCurry,
    spicyLevel: 2,
    tags: ['spicy']
  },
  {
    id: 'm4',
    name: 'Pad-Krapow d’Antan',
    englishName: 'Basil Stir-Fry (Pad Krapow)',
    description: 'Le plat de rue le plus prisé : émincé de poulet sauté intensément au wok avec du piment thaï, de l’ail frais et une profusion de basilic sacré poivré.',
    price: 240,
    category: 'mains',
    image: PHOTO_PLACEHOLDERS.padKrapow,
    spicyLevel: 3,
    tags: ['spicy', 'best-seller']
  },
  {
    id: 'm5',
    name: 'Poulet aux noix de cajou',
    englishName: 'Gai Pad Med Mamuang',
    description: 'Morceaux tendres de poulet sautés avec oignons croustillants, poivrons colorés et noix de cajou entières torréfiées dans une divine sauce soja-tamarin sucrée-salée.',
    price: 260,
    category: 'mains',
    image: PHOTO_PLACEHOLDERS.cashewChicken,
    spicyLevel: 1,
    tags: ['best-seller']
  },
  {
    id: 'm6',
    name: 'Riz frit thaïlandais traditionnel',
    englishName: 'Khao Pad Ancient Receipe',
    description: 'Riz au jasmin sauté de manière homogène avec œufs bio, oignons, tomates locales et ciboulette, parfumé à la sauce soja supérieure.',
    price: 220,
    category: 'mains',
    image: PHOTO_PLACEHOLDERS.fryRice,
    spicyLevel: 0,
    tags: []
  },
  {
    id: 'm7',
    name: 'Fruits de mer sautés au piment doux',
    englishName: 'Stir-Fried Talay',
    description: 'Sélection de fruits de mer extra-frais du marché de Bangkok (crevettes tigrées, calmars, moules de roche) sautés rapidement au basilic doux.',
    price: 380,
    category: 'mains',
    image: PHOTO_PLACEHOLDERS.seafood,
    spicyLevel: 1,
    tags: ['signature']
  },

  // VEGETARIAN MENU
  {
    id: 'v1',
    name: 'Curry Vert Végétarien & Tofu',
    englishName: 'Gaeng Keow Wan Pak',
    description: 'Version 100% végétale de notre curry vert signature, débordant d’aubergines thaïes, de tofu croustillant, brocolis frais, carottes et basilic aromatique.',
    price: 260,
    category: 'vegetarian',
    image: PHOTO_PLACEHOLDERS.greenCurry,
    spicyLevel: 2,
    tags: ['vegetarian', 'vegan', 'gluten-free']
  },
  {
    id: 'v2',
    name: 'Riz Frit aux Légumes Croquants',
    englishName: 'Khao Pad Pak',
    description: 'Riz parfumé au jasmin sauté au wok avec de tendres morceaux de tofu, brocolis, carottes et oignons grelots sans sauce de poisson.',
    price: 190,
    category: 'vegetarian',
    image: PHOTO_PLACEHOLDERS.fryRice,
    spicyLevel: 0,
    tags: ['vegetarian', 'vegan']
  },
  {
    id: 'v3',
    name: 'Nouilles Wok Végétariennes',
    englishName: 'Pad See Ew Pak',
    description: 'Nouilles de riz larges sautées de manière homogène avec du brocoli chinois, du tofu mariné et une riche sauce soja caramélisée végétarienne.',
    price: 210,
    category: 'vegetarian',
    image: PHOTO_PLACEHOLDERS.padThai,
    spicyLevel: 0,
    tags: ['vegetarian', 'vegan']
  },
  {
    id: 'v4',
    name: 'Tofu Sauté au Basilic Sacré',
    englishName: 'Pad Krapow Tofu',
    description: 'Blocs de tofu soyeux frits sautés intensément avec de l’ail, du piment sauvage et d’abondantes feuilles de basilic thaïlandais frais.',
    price: 220,
    category: 'vegetarian',
    image: PHOTO_PLACEHOLDERS.padKrapow,
    spicyLevel: 3,
    tags: ['vegetarian', 'vegan', 'spicy']
  },

  // DESSERTS
  {
    id: 'd1',
    name: 'Mango Sticky Rice Imperial',
    englishName: 'Khao Niew Mamuang',
    description: 'Le dessert culte thaïlandais : riz gluant parfumé infusé au lait de coco chaud, servi avec des tranches généreuses de mangue jaune thaïe extra douce d’une incroyable fraîcheur.',
    price: 180,
    category: 'desserts',
    image: PHOTO_PLACEHOLDERS.mangoSticky,
    spicyLevel: 0,
    tags: ['vegan', 'gluten-free', 'signature', 'best-seller']
  },
  {
    id: 'd2',
    name: 'Corbeille de fruits exotiques de saison',
    englishName: 'Mixed Thai Fruits Selection',
    description: 'Curation de fruits exotiques frais de Bangkok tranchés avec art : mangue sauvage, pitaya rouge, ananas herbe, et ramboutan juteux.',
    price: 140,
    category: 'desserts',
    image: PHOTO_PLACEHOLDERS.fruits,
    spicyLevel: 0,
    tags: ['vegetarian', 'vegan', 'gluten-free']
  },

  // DRINKS
  {
    id: 'b1',
    name: 'Thé thaï glacé maison Premium',
    englishName: 'Traditional Thai Iced Milk Tea',
    description: 'Thé noir thaïlandais infusé lentement avec des épices (anis étoilé, cardamome), adouci au lait condensé crémeux sur de la glace pilée.',
    price: 95,
    category: 'drinks',
    image: PHOTO_PLACEHOLDERS.thaiTea,
    spicyLevel: 0,
    tags: ['signature', 'best-seller']
  },
  {
    id: 'b2',
    name: 'Jus de Coco Fraîche Entière',
    englishName: 'Fresh Young Whole Coconut',
    description: 'Noix de coco verte fraîche entière découpée à la minute, remplie d’une eau de coco intensément rafraîchissante et de pulpe tendre.',
    price: 120,
    category: 'drinks',
    image: PHOTO_PLACEHOLDERS.fruits,
    spicyLevel: 0,
    tags: ['vegetarian', 'vegan', 'gluten-free']
  },
  {
    id: 'b3',
    name: 'Café Glacé Thaïlandais',
    englishName: 'Thai Iced Coffee (Oliang)',
    description: 'Café noir de style traditionnel thaïlandais de la province de Chiang Mai infusé à chaud puis servi glacé avec du lait condensé sucré.',
    price: 85,
    category: 'drinks',
    image: PHOTO_PLACEHOLDERS.thaiTea,
    spicyLevel: 0,
    tags: []
  },
  {
    id: 'b4',
    name: 'Eau minérale & Boissons gazeuses',
    englishName: 'Local Mineral Water & Soft Drinks',
    description: 'Sélection d’eau minérale purifiée, soda Singha ou boissons rafraîchissantes traditionnelles.',
    price: 45,
    category: 'drinks',
    image: PHOTO_PLACEHOLDERS.fruits,
    spicyLevel: 0,
    tags: []
  }
];

export const INITIAL_REVIEWS: UserReview[] = [
  {
    id: 'rev1',
    name: 'Thomas L.',
    rating: 5,
    comment: 'La meilleure cuisine thaïlandaise que nous avons goûtée durant nos deux semaines à Bangkok ! Le Pad Thaï est spectaculaire, préparé avec des ingrédients frais. Un accueil si chaleureux qui justifie amplement le nom du restaurant.',
    date: '2026-05-28',
    isVerified: true,
    helpfulCount: 42
  },
  {
    id: 'rev2',
    name: 'Chloé & David',
    rating: 5,
    comment: 'Un service d’une gentillesse exceptionnelle. On a l’impression d’être invités dans la famille. Le curry rouge thaï aux fruits de mer était crémeux, parfumé et pimenté juste ce qu’il faut. Le Mango Sticky Rice en dessert est divin.',
    date: '2026-05-15',
    isVerified: true,
    helpfulCount: 29
  },
  {
    id: 'rev3',
    name: 'Sarah M.',
    rating: 5,
    comment: 'Une expérience authentique que nous recommandons vivement. Recommandé par notre hôtel, nous y sommes retournés 3 fois de suite pour goûter tout le menu végétarien. Les rouleaux de printemps ont un croustillant incroyable !',
    date: '2026-05-02',
    isVerified: true,
    helpfulCount: 37
  }
];

export const GALLERY_ITEMS: GalleryItem[] = [
  // DISHES
  {
    id: 'g1',
    title: 'Pad Thai fumant au Wok',
    category: 'dish',
    imageUrl: PHOTO_PLACEHOLDERS.padThai,
    description: 'Nouilles sautées à la minute avec notre tamarin fait maison.'
  },
  {
    id: 'g2',
    title: 'Curry Vert Traditionnel',
    category: 'dish',
    imageUrl: PHOTO_PLACEHOLDERS.greenCurry,
    description: 'Crémeux, parfumé aux aubergines thaïes et basilic frais.'
  },
  {
    id: 'g3',
    title: 'Rouleaux de Printemps dorés',
    category: 'dish',
    imageUrl: PHOTO_PLACEHOLDERS.springRolls,
    description: 'Une enveloppe croustillante garnie d’herbes croquantes.'
  },
  {
    id: 'g4',
    title: 'Mango Sticky Rice Imperial',
    category: 'dish',
    imageUrl: PHOTO_PLACEHOLDERS.mangoSticky,
    description: 'Riz gluant onctueux à la coco et mangues jaunes sucrées.'
  },

  // RESTAURANT
  {
    id: 'g5',
    title: 'La Salle Principale',
    category: 'restaurant',
    imageUrl: PHOTO_PLACEHOLDERS.restaurantInterior,
    description: 'Un espace intime mariant noblesse du teck et éclairage tamisé.'
  },
  {
    id: 'g6',
    title: 'Notre Équipe Cuisine',
    category: 'restaurant',
    imageUrl: PHOTO_PLACEHOLDERS.teamCocktail,
    description: 'Une famille de chefs unis pour préserver les recettes d’antan.'
  },

  // THAILANDE
  {
    id: 'g7',
    title: 'Le Cœur Historique de Phra Nakhon',
    category: 'thailand',
    imageUrl: PHOTO_PLACEHOLDERS.thaiTemple,
    description: 'Situé à deux pas des plus majestueux temples de Bangkok.'
  },
  {
    id: 'g8',
    title: 'Bangkok Lumineux de Nuit',
    category: 'thailand',
    imageUrl: PHOTO_PLACEHOLDERS.bangkokNight,
    description: 'L’animation féérique de la cité des anges après le coucher du soleil.'
  },
  {
    id: 'g9',
    title: 'Marché aux Épices Local',
    category: 'thailand',
    imageUrl: PHOTO_PLACEHOLDERS.thaiMarket,
    description: 'Où nous sélectionnons personnellement chaque matin nos piments et galanga.'
  }
];
