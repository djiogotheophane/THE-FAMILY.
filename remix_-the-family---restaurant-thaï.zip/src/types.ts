export interface MenuItem {
  id: string;
  name: string;
  englishName?: string;
  nameFrench?: string;
  description: string;
  descriptionFrench?: string;
  price: number; // in Baht (THB) or EUR/USD depending on design, let's use THB with approximate € equivalents, e.g. "320 ฿ (~8.90 €)"
  category: 'starters' | 'mains' | 'vegetarian' | 'desserts' | 'drinks';
  image: string;
  spicyLevel: 0 | 1 | 2 | 3;
  tags: ('vegetarian' | 'vegan' | 'gluten-free' | 'signature' | 'spicy' | 'best-seller')[];
}

export interface CartItem {
  id: string;
  menuItem: MenuItem;
  quantity: number;
  notes?: string;
  selectedOption?: string; // e.g. "Chicken", "Prawns", "Tofu"
}

export interface Reservation {
  id: string;
  name: string;
  phone: string;
  email: string;
  date: string;
  time: string;
  guests: number;
  specialRequests?: string;
  status: 'pending' | 'confirmed';
  createdAt: string;
}

export interface UserReview {
  id: string;
  name: string;
  rating: number; // 1-5
  comment: string;
  date: string;
  isVerified: boolean;
  helpfulCount: number;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'dish' | 'restaurant' | 'thailand';
  imageUrl: string;
  description: string;
}
