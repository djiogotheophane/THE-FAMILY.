import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, LANGUAGES, TRANSLATIONS } from '../translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<Language>('fr');

  useEffect(() => {
    // Check if the user set a preferred language in localStorage previously
    const savedLang = localStorage.getItem('the_family_preferred_language') as Language;
    if (savedLang && LANGUAGES.some(l => l.code === savedLang)) {
      setLanguageState(savedLang);
    } else {
      // Opt: try setting language from browser language
      const browserLang = navigator.language.slice(0, 2) as Language;
      if (LANGUAGES.some(l => l.code === browserLang)) {
        setLanguageState(browserLang);
      }
    }
  }, []);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('the_family_preferred_language', lang);
  };

  const t = (key: string): string => {
    const section = TRANSLATIONS[language];
    if (section && section[key]) {
      return section[key];
    }
    // Fallback to greenlight English or French
    const fallbackFrSection = TRANSLATIONS['fr'];
    if (fallbackFrSection && fallbackFrSection[key]) {
      return fallbackFrSection[key];
    }
    const fallbackEnSection = TRANSLATIONS['en'];
    if (fallbackEnSection && fallbackEnSection[key]) {
      return fallbackEnSection[key];
    }
    // Final return key name if nothing else works
    return key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
