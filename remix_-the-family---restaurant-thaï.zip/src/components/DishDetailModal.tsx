import React, { useState } from 'react';
import { X, ShoppingCart, Flame, HelpCircle, Check, Play, Film, Award, Clock, Heart } from 'lucide-react';
import { MenuItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface DishDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  dish: MenuItem | null;
  onAddToCart: (item: MenuItem, selectedOption?: string) => void;
}

export default function DishDetailModal({ isOpen, onClose, dish, onAddToCart }: DishDetailModalProps) {
  const { language, t } = useLanguage();
  const [isPlayingVideo, setIsPlayingVideo] = useState(false);
  const [showRecipeSecret, setShowRecipeSecret] = useState(false);

  if (!dish) return null;

  const dishDisplayName = language === 'fr' ? dish.name : (dish.englishName || dish.name);
  const secondaryName = language === 'fr' ? dish.englishName : dish.name;

  // Premium mock list of details matching the dish's flavor profile
  const getDishDetails = (id: string) => {
    switch (id) {
      case 's1':
        return {
          prepTime: '15 min',
          calories: '180 kcal',
          difficulty: language === 'fr' ? 'Facile' : 'Easy',
          ingredients: language === 'fr' 
            ? ['Vermicelles de haricots', 'Chou émincé', 'Carottes croquantes', 'Tofu émincé', 'Sauce soja suprême', 'Galette de riz croustillante']
            : ['Bean thread glass noodles', 'Shredded cabbage', 'Crispy carrots', 'Minced organic tofu', 'Superior soy sauce', 'Crispy rice wrapper'],
          allergens: language === 'fr' ? ['Soja', 'Gluten (Traces)'] : ['Soy', 'Gluten (Traces)'],
          videoUrl: 'https://www.youtube.com/embed/9NfRff8-nO8', // Crispy rolls recipe
          secret: language === 'fr' 
            ? "Pour obtenir le craquant parfait, nos rouleaux sont frits à deux températures distinctes dans une huile de sésame légère."
            : "To reach the ultimate crunch, our spring rolls are double-fried at distinct temperatures in pure light sesame oil."
        };
      case 's2':
        return {
          prepTime: '20 min',
          calories: '240 kcal',
          difficulty: language === 'fr' ? 'Moyen' : 'Medium',
          ingredients: language === 'fr' 
            ? ['Crevettes tigrées géantes', 'Citronnelle fraîche', 'Galanga noble', 'Feuilles de kaffir', 'Piments oiseau', 'Champignons paille', 'Coriandre sauvage']
            : ['Giant tiger prawns', 'Fresh lemongrass stalks', 'Noble galangal root', 'Kaffir lime leaves', 'Bird’s eye chilies', 'Straw mushrooms', 'Wild coriander'],
          allergens: language === 'fr' ? ['Crustacés', 'Poisson'] : ['Crustaceans', 'Fish'],
          videoUrl: 'https://www.youtube.com/embed/H77-G0P8vjQ', // Tom Yum recipe
          secret: language === 'fr' 
            ? "Le secret réside dans le bouillon : nous faisons infuser les têtes de crevettes grillées pendant 4 heures pour libérer tous les sucs essentiels."
            : "The secret is in the broth: we infuse simmered roasted prawn heads for 4 hours to extract the rich essential umami flavors."
        };
      case 's3':
        return {
          prepTime: '12 min',
          calories: '150 kcal',
          difficulty: language === 'fr' ? 'Moyen' : 'Medium',
          ingredients: language === 'fr' 
            ? ['Papaye verte rapée', 'Piments frais', 'Ail violet', 'Tomates cerises juteuses', 'Cacahuètes grillées', 'Haricots serpent', 'Jus de citron vert pressé']
            : ['Shredded green papaya', 'Bird’s eye chilies', 'Purple garlic', 'Juicy cherry tomatoes', 'Roasted peanuts', 'Snake beans', 'Freshly pressed lime juice'],
          allergens: language === 'fr' ? ['Arachides', 'Poisson'] : ['Peanuts', 'Fish'],
          videoUrl: 'https://www.youtube.com/embed/rP7B2v-a4Lg', // Somtam papaya salad
          secret: language === 'fr' 
            ? "Nous pilons d'abord l'ail et les piments vigoureusement, puis nous écrasons délicatement la papaye pour qu'elle absorbe le jus sans perdre son croquant."
            : "We bruise the garlic and chilies vigorously first, then gently muddle the papaya so it absorbs the juices while maintaining its absolute crunch."
        };
      case 'm1':
        return {
          prepTime: '25 min',
          calories: '480 kcal',
          difficulty: language === 'fr' ? 'Chef' : 'Chef-Only',
          ingredients: language === 'fr' 
            ? ['Nouilles de riz sèches', 'Pâte de tamarin pure', 'Œuf fermier bio', 'Tofu jaune ferme', 'Ciboulette chinoise', 'Cacahuètes torréfiées', 'Germes de soja croustillants']
            : ['Dry flat rice noodles', 'Pure tamarind paste', 'Organic farm egg', 'Firm yellow tofu', 'Garlic chives', 'House-roasted peanuts', 'Crispy mung bean sprouts'],
          allergens: language === 'fr' ? ['Arachides', 'Œufs', 'Soja'] : ['Peanuts', 'Eggs', 'Soy'],
          videoUrl: 'https://www.youtube.com/embed/S_g9qN8w3c8', // Classic Pad Thai
          secret: language === 'fr' 
            ? "Notre inimitable sauce Pad Thaï est mijotée lentement pendant 6 heures avec du sucre de palme sauvage, du tamarin aigre et du jus de poisson noble."
            : "Our signature Pad Thai sauce is slow-cooked for 6 hours using organic forest palm sugar, sour tamarind nectar, and premium fish extract."
        };
      case 'm2':
        return {
          prepTime: '30 min',
          calories: '410 kcal',
          difficulty: language === 'fr' ? 'Moyen' : 'Medium',
          ingredients: language === 'fr' 
            ? ['Lait de coco frais', 'Pâte de piment vert artisanale', 'Aubergines siamoises', 'Feuilles de basilic doux', 'Pousses de bambou', 'Feuilles de kaffir fraîches']
            : ['Fresh squeezed coconut milk', 'Artisanal green chili paste', 'Thai eggplant globes', 'Sweet basil leaves', 'Tender bamboo shoots', 'Fresh kaffir lime leaves'],
          allergens: language === 'fr' ? ['Poisson', 'Crustacés (Pâte)'] : ['Fish', 'Crustaceans (in paste)'],
          videoUrl: 'https://www.youtube.com/embed/fF58Y16kK2A', // Green curry recipe
          secret: language === 'fr' 
            ? "Nous torréfions la pâte de curry dans le lait de coco réduit pour séparer l'huile de coco naturelle, ce qui libère d'intenses parfums herbeux."
            : "We pan-fry and crack the curry paste inside reduced coconut cream to release the natural coconut oils and unlock intense herbal fragrances."
        };
      default:
        return {
          prepTime: '20 min',
          calories: '350 kcal',
          difficulty: language === 'fr' ? 'Moyen' : 'Medium',
          ingredients: language === 'fr' 
            ? ['Épices thaïes traditionnelles', 'Herbes aromatiques du potager', 'Légumes de saison sélectionnés', 'Sauce d’assaisonnement exclusive']
            : ['Traditional Thai spices', 'Garden aromatic herbs', 'Selected seasonal vegetables', 'Exclusive seasoning glaze'],
          allergens: language === 'fr' ? ['Soja'] : ['Soy'],
          videoUrl: 'https://www.youtube.com/embed/9NfRff8-nO8',
          secret: language === 'fr' 
            ? "Ce plat est cuit à feu extrêmement vif au wok traditionnel (le souffle du wok - Wok Hei) pour caraméliser les molécules sans brûler."
            : "This dish is cooked with rapid, extreme high-heat stir-frying (Wok Hei) to caramelize the flavors without scorching the ingredients."
        };
    }
  };

  const details = getDishDetails(dish.id);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-brand-dark/90 backdrop-blur-md overflow-y-auto">
      {/* Background click to dismiss */}
      <div className="fixed inset-0" onClick={onClose} />

      <motion.div
        initial={{ opacity: 0, y: 30, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 30, scale: 0.95 }}
        transition={{ duration: 0.35, ease: 'easeOut' }}
        className="w-full max-w-4xl bg-brand-charcoal border border-brand-gold/25 rounded-3xl overflow-hidden relative z-10 shadow-2xl"
      >
        {/* Absolute header actions */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 text-brand-gold bg-brand-dark/80 hover:bg-brand-gold hover:text-brand-dark rounded-full border border-brand-gold/15 transition-all cursor-pointer shadow-lg"
          aria-label="Fermer"
        >
          <X size={18} />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Images / Video column Left */}
          <div className="relative bg-brand-dark h-72 md:h-full min-h-[300px] flex flex-col justify-between overflow-hidden">
            <AnimatePresence mode="wait">
              {!isPlayingVideo ? (
                <motion.div
                  key="image"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 w-full h-full"
                >
                  <img
                    src={dish.image}
                    alt={dishDisplayName}
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-dark to-transparent opacity-70" />
                </motion.div>
              ) : (
                <motion.div
                  key="video"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="absolute inset-0 w-full h-full bg-black"
                >
                  <iframe
                    src={`${details.videoUrl}?autoplay=1`}
                    title="Cookery Video"
                    className="w-full h-full"
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Float Badge Over Image */}
            <div className="absolute top-4 left-4 z-10 flex flex-wrap gap-1.5">
              {dish.tags.includes('signature') && (
                <span className="flex items-center gap-1 bg-brand-gold text-brand-dark text-[9px] font-bold tracking-widest font-mono uppercase px-2.5 py-1 rounded">
                  <Award size={11} />
                  CHEF SPECIALTY
                </span>
              )}
              {dish.spicyLevel > 0 && (
                <span className="flex items-center gap-1 bg-brand-red text-white text-[9px] font-bold tracking-widest font-mono uppercase px-2.5 py-1 rounded">
                  <Flame size={10} className="fill-white" />
                  SPICY Lvl {dish.spicyLevel}
                </span>
              )}
            </div>

            {/* Video toggle button bottom-left */}
            <div className="absolute bottom-4 left-4 z-10">
              <button
                onClick={() => setIsPlayingVideo(!isPlayingVideo)}
                className="flex items-center gap-2 bg-brand-gold/95 backdrop-blur text-brand-dark hover:bg-yellow-500 font-mono font-black text-[10px] uppercase tracking-wider px-3.5 py-2.5 rounded-full shadow-lg transition-all cursor-pointer"
              >
                {isPlayingVideo ? (
                  <>
                    <Film size={12} />
                    <span>{language === 'fr' ? 'Afficher la Photo' : 'Show Photo'}</span>
                  </>
                ) : (
                  <>
                    <Play size={12} className="fill-brand-dark" />
                    <span>{language === 'fr' ? 'Voir la Recette (Vidéo)' : 'Watch Recipe (Video)'}</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Dish Details column Right */}
          <div className="p-6 sm:p-8 flex flex-col justify-between max-h-[600px] overflow-y-auto">
            <div className="space-y-5">
              {/* Headings */}
              <div>
                <span className="text-[10px] font-mono text-brand-gold uppercase tracking-[0.25em]">
                  {dish.category}
                </span>
                <h3 className="font-serif text-2xl sm:text-3xl font-bold text-brand-beige mt-1">
                  {dishDisplayName}
                </h3>
                {secondaryName && (
                  <p className="text-[11px] font-mono uppercase tracking-widest text-brand-gold/60 mt-1 italic">
                    {secondaryName}
                  </p>
                )}
              </div>

              {/* Main Description */}
              <p className="text-xs sm:text-sm text-brand-beige/75 leading-relaxed font-sans">
                {dish.description}
              </p>

              {/* Quick specifications timeline */}
              <div className="grid grid-cols-3 gap-2 bg-brand-dark/45 p-3 rounded-xl border border-brand-gold/10 font-mono text-[10px]">
                <div className="text-center border-r border-brand-gold/10">
                  <span className="text-[#F5E6C8]/40 block uppercase">{language === 'fr' ? 'Préparation' : 'Prep'}</span>
                  <span className="text-brand-gold font-bold flex items-center justify-center gap-1 mt-0.5">
                    <Clock size={11} />
                    {details.prepTime}
                  </span>
                </div>
                <div className="text-center border-r border-brand-gold/10">
                  <span className="text-[#F5E6C8]/40 block uppercase">Calories</span>
                  <span className="text-brand-gold font-bold block mt-0.5">{details.calories}</span>
                </div>
                <div className="text-center">
                  <span className="text-[#F5E6C8]/40 block uppercase">Niveau</span>
                  <span className="text-brand-gold font-bold block mt-0.5">{details.difficulty}</span>
                </div>
              </div>

              {/* Ingredients tag list */}
              <div className="space-y-2">
                <h4 className="text-[11px] uppercase tracking-wider font-mono text-brand-gold font-bold">
                  {language === 'fr' ? 'Ingrédients Clés' : 'Key Ingredients'}
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {details.ingredients.map((ing) => (
                    <span key={ing} className="px-2.5 py-1 bg-brand-gold/5 border border-brand-gold/10 rounded-lg text-xs text-brand-beige/80 font-sans">
                      {ing}
                    </span>
                  ))}
                </div>
              </div>

              {/* Allergens warning */}
              <div className="text-[10px] font-sans flex items-center gap-2 text-[#F5E6C8]/50 bg-brand-red/5 p-2.5 rounded-lg border border-brand-red/10">
                <HelpCircle size={13} className="text-brand-gold shrink-0" />
                <span>
                  <strong>{language === 'fr' ? 'Allergènes présents' : 'Allergens detected'} :</strong>{' '}
                  {details.allergens.join(', ')}
                </span>
              </div>

              {/* Interactive Secret Chef view */}
              <div className="border border-brand-gold/15 rounded-xl overflow-hidden bg-brand-dark/20 text-xs">
                <button
                  onClick={() => setShowRecipeSecret(!showRecipeSecret)}
                  className="w-full flex items-center justify-between p-3 select-none text-left border-b border-brand-gold/5 text-brand-gold font-bold tracking-wide transition-all hover:bg-brand-gold/5"
                >
                  <span className="font-serif italic">{language === 'fr' ? '💡 Le Secret du Chef' : '💡 Chef’s Culinary Secret'}</span>
                  <span className="font-mono text-xs">{showRecipeSecret ? '[-]' : '[+]'}</span>
                </button>
                <AnimatePresence>
                  {showRecipeSecret && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="p-3 text-brand-beige/70 leading-relaxed italic bg-brand-dark/40 font-serif"
                    >
                      "{details.secret}"
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>

            {/* Footer pricing and Order CTA */}
            <div className="border-t border-brand-gold/15 pt-6 mt-6 flex items-center justify-between">
              <div>
                <span className="text-[10px] text-[#F5E6C8]/40 uppercase block font-mono">Prix du Chef</span>
                <div className="flex items-baseline gap-1.5">
                  <span className="text-2xl font-serif text-brand-gold font-black">{dish.price} ฿</span>
                  <span className="text-xs text-[#F5E6C8]/35 font-mono">~{(dish.price / 36).toFixed(1)} €</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    onAddToCart(dish);
                    onClose();
                  }}
                  className="flex items-center gap-2.5 bg-gradient-to-r from-brand-gold to-yellow-600 hover:from-yellow-600 hover:to-brand-gold text-brand-dark px-5 py-3 rounded-xl font-bold font-mono text-xs uppercase tracking-wider shadow-lg hover:shadow-brand-gold/20 transform hover:-translate-y-0.5 transition-all cursor-pointer"
                >
                  <ShoppingCart size={14} />
                  <span>{language === 'fr' ? 'Ajouter ce plat' : 'Add to Order'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
