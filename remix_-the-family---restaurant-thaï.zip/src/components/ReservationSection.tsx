import React, { useState, useEffect } from 'react';
import { Calendar, Phone, Mail, Users, MessageSquareCode, Check, Star, ShieldCheck, Ticket, Download, ArrowRight, Table } from 'lucide-react';
import { Reservation } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function ReservationSection() {
  const { t, language } = useLanguage();
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('19:00');
  const [guests, setGuests] = useState(2);
  const [ambianceZone, setAmbianceZone] = useState<'terrace' | 'interior' | 'kitchen'>('interior');
  const [specialRequests, setSpecialRequests] = useState('');

  // Voucher confirmation states
  const [isBooked, setIsBooked] = useState(false);
  const [confirmedReservationCode, setConfirmedReservationCode] = useState('');
  const [previousReservations, setPreviousReservations] = useState<Reservation[]>([]);

  // Time preset slots
  const timeSlots = [
    '12:00', '12:30', '13:00', '13:30', '18:00', '18:30', '19:00', '19:30', '20:00', '20:30', '21:00'
  ];

  // Zones configuration selector
  const ambianceZones = [
    { key: 'interior', label: language === 'fr' ? 'Salle Royale en Teck' : 'Teak Royal Hall', desc: language === 'fr' ? 'Chaud & Tamisé' : 'Warm & Cozy' },
    { key: 'terrace', label: language === 'fr' ? 'Terrasse Extérieure' : 'Garden Terrace', desc: language === 'fr' ? 'Cour Douce' : 'Sweet Breeze' },
    { key: 'kitchen', label: language === 'fr' ? "Près de l'Open Kitchen" : 'Open Kitchen View', desc: language === 'fr' ? 'Spectacle Woks' : 'Wok Mastery' },
  ];

  useEffect(() => {
    const list = localStorage.getItem('the_family_bookings_history');
    if (list) {
      try {
        setPreviousReservations(JSON.parse(list));
      } catch (e) {}
    }
  }, []);

  const handleBookTable = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone || !email || !date) return;

    const bookingCode = `REC-${Math.floor(1000 + Math.random() * 9000)}`;

    const added: Reservation = {
      id: `booking-${Date.now()}`,
      name: name.trim(),
      phone: phone.trim(),
      email: email.trim(),
      date,
      time,
      guests,
      specialRequests: specialRequests.trim(),
      status: 'confirmed',
      createdAt: new Date().toISOString()
    };

    const updated = [added, ...previousReservations];
    setPreviousReservations(updated);
    localStorage.setItem('the_family_bookings_history', JSON.stringify(updated));

    setConfirmedReservationCode(bookingCode);
    setIsBooked(true);
  };

  const resetBookingForm = () => {
    setName('');
    setPhone('');
    setEmail('');
    setDate('');
    setSpecialRequests('');
    setIsBooked(false);
  };

  return (
    <section id="reservation" className="py-24 bg-brand-charcoal relative overflow-hidden border-t border-brand-gold/10">
      {/* Visual glowing ornaments */}
      <div className="absolute right-0 bottom-0 w-[450px] h-[450px] bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.05),transparent_60%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          
          {/* Form left (7 cols of 12) or the generated receipt card */}
          <div className="lg:col-span-7">
            <AnimatePresence mode="wait">
              {!isBooked ? (
                /* Dynamic booking form layout */
                <motion.div
                  key="form-panel"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ duration: 0.4 }}
                  className="bg-brand-dark/90 rounded-3xl border border-brand-gold/20 p-6 sm:p-10 shadow-2xl relative"
                >
                  {/* Ornate details inside form card */}
                  <div className="absolute top-6 right-6 flex items-center gap-1.5 text-[8px] font-mono text-brand-gold bg-brand-gold/10 px-2.5 py-1 rounded border border-brand-gold/20 tracking-wider">
                    <ShieldCheck size={11} />
                    {language === 'fr' ? "RÉSERVATION RAPIDE SÉCURISÉE" : "SECURED FAST BOOKING"}
                  </div>

                  <span className="text-xs font-mono uppercase tracking-[0.25em] text-brand-gold block mb-2">
                    {t('booking.badge')}
                  </span>
                  <h3 className="font-serif text-2xl sm:text-3xl font-bold text-brand-beige mb-6">
                    {t('booking.title')}
                  </h3>

                  <form onSubmit={handleBookTable} className="space-y-6">
                    
                    {/* Zones configuration selector */}
                    <div className="space-y-2">
                      <label className="block text-[10px] font-mono uppercase tracking-widest text-brand-gold">
                        {t('booking.lblAmbiance') || 'Ambiance'}
                      </label>
                      <div className="grid grid-cols-3 gap-3">
                        {ambianceZones.map((z) => (
                          <div
                            key={z.key}
                            onClick={() => setAmbianceZone(z.key as any)}
                            className={`p-3 rounded-xl border text-center cursor-pointer transition-all ${
                              ambianceZone === z.key
                                ? 'border-brand-gold bg-brand-gold/10 text-brand-gold font-bold shadow'
                                : 'border-brand-gold/10 bg-brand-charcoal/40 text-brand-beige/50 hover:bg-brand-gold/5'
                            }`}
                          >
                            <Table size={16} className="mx-auto mb-1.5" />
                            <p className="text-[11px] font-bold tracking-tight">{z.label}</p>
                            <p className="text-[9px] text-[#F5E6C8]/40 mt-1">{z.desc}</p>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Inputs Row 1: Name & Phone */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="space-y-1.5">
                        <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">
                          {t('booking.lblName')}
                        </label>
                        <div className="relative">
                          <input
                            type="text"
                            required
                            placeholder={language === 'fr' ? "Vos prénoms" : "First & Last Name"}
                            value={name}
                            onChange={(e) => setName(e.target.value)}
                            className="w-full bg-brand-charcoal border border-brand-gold/15 rounded-lg px-4 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold"
                          />
                        </div>
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">
                          {t('booking.lblPhone')}
                        </label>
                        <div className="relative">
                          <input
                            type="tel"
                            required
                            placeholder="ex: +66 95..."
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            className="w-full bg-brand-charcoal border border-brand-gold/15 rounded-lg px-4 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold font-mono"
                          />
                        </div>
                      </div>
                    </div>

                    {/* Inputs Row 2: Mail & Guests Count */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="space-y-1.5">
                        <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">
                          {t('booking.lblEmail')}
                        </label>
                        <input
                          type="email"
                          required
                          placeholder="client@reception.com"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          className="w-full bg-brand-charcoal border border-brand-gold/15 rounded-lg px-4 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">
                          {t('booking.lblGuests')}
                        </label>
                        <div className="flex items-center justify-between bg-brand-charcoal border border-brand-gold/15 rounded-lg px-3 py-1.5">
                          <button
                            type="button"
                            onClick={() => setGuests(prev => Math.max(1, prev - 1))}
                            className="p-1 px-2.5 bg-brand-gold/10 hover:bg-brand-gold/25 rounded font-bold text-center text-brand-gold cursor-pointer"
                          >
                            -
                          </button>
                          <span className="font-mono text-xs font-bold text-brand-beige px-4 flex items-center gap-1.5">
                            <Users size={13} className="text-brand-gold" />
                            {guests} {guests > 1 ? (language === 'fr' ? 'personnes' : 'guests') : (language === 'fr' ? 'personnes' : 'guest')}
                          </span>
                          <button
                            type="button"
                            onClick={() => setGuests(prev => Math.min(20, prev + 1))}
                            className="p-1 px-2.5 bg-brand-gold/10 hover:bg-brand-gold/25 rounded font-bold text-center text-brand-gold cursor-pointer"
                          >
                            +
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Inputs Row 3: Date & Hour Slots */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div className="space-y-1.5">
                        <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">
                          {t('booking.lblDate')}
                        </label>
                        <input
                          type="date"
                          required
                          value={date}
                          onChange={(e) => setDate(e.target.value)}
                          min={new Date().toISOString().split('T')[0]} // Block historical dates
                          className="w-full bg-brand-charcoal border border-brand-gold/15 rounded-lg px-4 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold font-mono cursor-pointer"
                        />
                      </div>

                      <div className="space-y-1.5">
                        <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">
                          {t('booking.lblTime')} ({time})
                        </label>
                        <div className="flex items-center gap-2 bg-brand-charcoal border border-brand-gold/15 rounded-lg px-3 py-2 text-xs">
                          <select
                            value={time}
                            onChange={(e) => setTime(e.target.value)}
                            className="w-full bg-transparent text-xs text-brand-beige focus:outline-none cursor-pointer"
                          >
                            {timeSlots.map((ts) => (
                              <option key={ts} value={ts} className="bg-brand-charcoal text-brand-beige">
                                {ts}
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                    </div>

                    {/* Demandes spéciales */}
                    <div className="space-y-1.5">
                      <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">
                        {t('booking.lblReq')}
                      </label>
                      <textarea
                        rows={2}
                        placeholder={t('booking.lblReqPl')}
                        value={specialRequests}
                        onChange={(e) => setSpecialRequests(e.target.value)}
                        className="w-full bg-brand-charcoal border border-brand-gold/15 rounded-lg p-3 text-xs text-brand-beige focus:outline-none focus:border-brand-gold"
                      />
                    </div>

                    {/* Term Agreement */}
                    <p className="text-[10px] leading-relaxed text-[#F5E6C8]/45">
                      {language === 'fr' 
                        ? "En réservant chez nous, vous acceptez de recevoir une confirmation instantanée. Toute réservation est fermement conservée pendant 15 minutes d'attente maximum d'écart."
                        : "By booking with us, you agree to receive immediate confirmation. Tables are held for a maximum of 15 minutes tolerance after reservation time."}
                    </p>

                    {/* Submit CTA */}
                    <button
                      type="submit"
                      className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-brand-gold to-yellow-600 hover:from-yellow-600 hover:to-brand-gold text-brand-dark py-4 rounded-xl font-bold font-mono text-xs uppercase tracking-wider shadow-lg transform hover:-translate-y-0.5 transition-all cursor-pointer"
                    >
                      <Calendar size={15} />
                      {t('booking.btnBook')}
                    </button>

                  </form>
                </motion.div>
              ) : (
                /* Dynamic Golden Lounge Voucher / Ticket component */
                <motion.div
                  key="voucher-panel"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.4 }}
                  className="bg-brand-dark border-2 border-dashed border-brand-gold rounded-3xl p-6 sm:p-10 shadow-2xl relative text-center relative overflow-hidden"
                >
                  <div className="absolute top-0 left-0 w-full h-1.5 bg-brand-gold" />
                  
                  {/* Decorative stamp banner */}
                  <div className="w-16 h-16 rounded-full bg-brand-gold/15 border border-brand-gold/45 text-brand-gold flex items-center justify-center mx-auto text-xl font-bold font-serif mb-6 shadow">
                    T.F
                  </div>

                  <span className="text-[10px] font-mono uppercase text-brand-green bg-brand-green/10 px-2.5 py-1 rounded-full border border-brand-green/20">
                    ✔ {language === 'fr' ? 'CONFIRMATION VALIDÉE INSTANTANÉMENT' : 'SEAT INSTANTLY CONFIRMED'}
                  </span>

                  <h3 className="font-serif text-2xl font-bold text-white mt-4 tracking-tight">
                    {t('voucher.title')}
                  </h3>
                  <p className="text-xs text-brand-beige/50 max-w-sm mx-auto font-sans mt-2">
                    {t('voucher.sub')}
                  </p>

                  {/* Booking Receipt details box */}
                  <div className="my-8 bg-brand-charcoal/80 border border-brand-gold/15 rounded-2xl p-6 text-left space-y-4">
                    <div className="flex justify-between items-center border-b border-brand-gold/10 pb-3">
                      <div>
                        <span className="text-[8px] font-mono text-brand-gold uppercase tracking-widest">{language === 'fr' ? 'Code Réservation' : 'Booking Code'}</span>
                        <h4 className="text-lg font-mono font-black text-white uppercase tracking-wider">{confirmedReservationCode}</h4>
                      </div>
                      <div className="text-right">
                        <span className="text-[8px] font-mono text-brand-gold uppercase tracking-widest">{t('voucher.statusTitle')}</span>
                        <span className="block text-xs font-mono font-bold text-brand-green uppercase">● {language === 'fr' ? 'GARANTI' : 'GUARANTEED'}</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-xs font-sans">
                      <div>
                        <span className="text-[#F5E6C8]/40 block text-[9px] uppercase tracking-wider">{t('voucher.guest')}</span>
                        <span className="text-brand-beige font-semibold truncate block">{name}</span>
                      </div>
                      <div>
                        <span className="text-[#F5E6C8]/40 block text-[9px] uppercase tracking-wider">{t('voucher.zone')}</span>
                        <span className="text-brand-beige font-semibold">
                          {ambianceZone === 'interior' 
                            ? (language === 'fr' ? 'Salle Royale s. s.' : 'Royal Suite') 
                            : ambianceZone === 'terrace' 
                              ? (language === 'fr' ? 'Terrasse s. s.' : 'Terrace') 
                              : (language === 'fr' ? 'Open Kitchen s. s.' : 'Open Kitchen')}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#F5E6C8]/40 block text-[9px] uppercase tracking-wider">{t('voucher.date')}</span>
                        <span className="text-brand-beige font-mono font-bold">{date}</span>
                      </div>
                      <div>
                        <span className="text-[#F5E6C8]/40 block text-[9px] uppercase tracking-wider">{t('voucher.time')}</span>
                        <span className="text-brand-beige font-mono font-bold">{time}</span>
                      </div>
                      <div>
                        <span className="text-[#F5E6C8]/40 block text-[9px] uppercase tracking-wider">{t('voucher.size')}</span>
                        <span className="text-brand-gold font-bold font-mono">
                          {guests} {guests > 1 ? (language === 'fr' ? 'personnes' : 'guests') : (language === 'fr' ? 'personne' : 'guest')}
                        </span>
                      </div>
                      <div>
                        <span className="text-[#F5E6C8]/40 block text-[9px] uppercase tracking-wider">{t('voucher.contact')}</span>
                        <span className="text-brand-beige font-mono font-semibold text-xs leading-none">{phone}</span>
                      </div>
                    </div>

                    {specialRequests && (
                      <div className="border-t border-brand-gold/5 pt-3.5 text-xs font-sans">
                        <span className="text-[#F5E6C8]/40 text-[9px] uppercase tracking-wider block">{t('voucher.notes')}</span>
                        <p className="text-brand-beige/85 italic leading-relaxed">"{specialRequests}"</p>
                      </div>
                    )}
                  </div>

                  {/* Simulated QR Code for authentic ticketing feel */}
                  <div className="w-24 h-24 bg-white border border-brand-gold p-1.5 rounded-xl mx-auto shadow-inner select-none mb-6">
                    <svg viewBox="0 0 100 100" className="w-full h-full text-brand-dark fill-current">
                      {/* Abstract neat QR simulation blocks */}
                      <rect x="0" y="0" width="25" height="25" />
                      <rect x="5" y="5" width="15" height="15" fill="white" />
                      <rect x="75" y="0" width="25" height="25" />
                      <rect x="80" y="5" width="15" height="15" fill="white" />
                      <rect x="0" y="75" width="25" height="25" />
                      <rect x="5" y="80" width="15" height="15" fill="white" />
                      <rect x="35" y="35" width="30" height="30" />
                      <rect x="40" y="40" width="20" height="20" fill="white" />
                      <rect x="10" y="35" width="10" height="12" />
                      <rect x="6" y="56" width="30" height="5" />
                      <rect x="37" y="10" width="25" height="4" />
                      <rect x="76" y="50" width="10" height="10" />
                      <rect x="55" y="75" width="20" height="25" />
                      <rect x="60" y="80" width="10" height="10" fill="white" />
                    </svg>
                  </div>

                  {/* Action triggers */}
                  <div className="flex gap-4">
                    <button
                      onClick={resetBookingForm}
                      className="w-1/2 py-3 border border-brand-gold/30 text-brand-beige rounded-xl text-xs font-mono uppercase hover:bg-brand-gold/5 cursor-pointer"
                    >
                      {t('voucher.btnNew')}
                    </button>
                    <button
                      onClick={() => window.print()}
                      className="w-1/2 py-3 bg-brand-gold text-brand-dark font-black rounded-xl text-xs font-mono uppercase hover:bg-yellow-600 shadow-md flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Download size={13} />
                      {t('voucher.btnPrint')}
                    </button>
                  </div>

                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Guidelines info right panel (5 cols of 12) */}
          <div className="lg:col-span-5 space-y-6">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
              – {language === 'fr' ? 'Le Protocole' : 'The Protocol'}
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-bold text-brand-beige leading-tight tracking-tight">
              {language === 'fr' ? 'Sérénité &' : 'Serenity &'} <span className="italic font-serif text-brand-gold">{language === 'fr' ? 'Hospitalité' : 'Hospitality'}</span>
            </h2>
            <div className="w-12 h-0.5 bg-brand-gold" />

            <div className="space-y-4 text-xs sm:text-sm text-brand-beige/70 leading-relaxed font-sans">
              <p>{t('booking.p1')}</p>
              <p>{t('booking.p2')}</p>
              <p>{t('booking.p3')}</p>
            </div>

            {/* Direct hotline shortcut card for help */}
            <div className="bg-brand-dark/50 border border-brand-gold/10 p-6 rounded-2xl flex items-center gap-4 hover:border-brand-gold/25 transition-all">
              <div className="w-11 h-11 rounded-full bg-brand-gold/5 border border-brand-gold/20 flex items-center justify-center text-brand-gold shrink-0">
                <Users size={18} />
              </div>
              <div className="min-w-0">
                <h4 className="font-serif font-bold text-sm text-brand-beige">
                  {language === 'fr' ? "Besoin de conseils d'assise ?" : "Need seating assistance?"}
                </h4>
                <p className="text-[11px] text-[#F5E6C8]/45 mt-0.5 leading-tight truncate">Hotline: +66 95 896 0395 ({language === 'fr' ? 'Assistance directe' : 'Direct Concierge'})</p>
              </div>
            </div>

            {/* If there is a reservation saved history, display a minor ticker list */}
            {previousReservations.length > 0 && (
              <div className="pt-4">
                <h4 className="text-[10px] uppercase font-mono tracking-widest text-[#D4AF37] mb-2.5">
                  {language === 'fr' ? 'Vos Réservations Récentes' : 'Your Recent Reservations'} ({previousReservations.length})
                </h4>
                <div className="space-y-2 max-h-32 overflow-y-auto pr-1">
                  {previousReservations.map((res) => (
                    <div key={res.id} className="bg-brand-dark/45 rounded-lg p-3 text-[11px] flex justify-between items-center border border-brand-gold/5 font-sans">
                      <div>
                        <span className="font-bold text-brand-beige">{res.name}</span>
                        <span className="text-zinc-500 mx-1.5 font-mono">|</span>
                        <span className="text-[#F5E6C8]/60 font-mono">{res.date} ({res.time})</span>
                      </div>
                      <span className="text-brand-green font-mono font-bold text-[9px] bg-brand-green/10 px-1.5 py-0.5 rounded uppercase">✔ {language === 'fr' ? 'Confirmée' : 'Confirmed'}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

        </div>
      </div>
    </section>
  );
}
