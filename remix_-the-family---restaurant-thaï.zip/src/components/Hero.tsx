import React from 'react';
import { motion } from 'motion/react';
import { Calendar, ShoppingBag, Star, ArrowDown, MapPin } from 'lucide-react';
import { HERO_BACKGROUND } from '../data';
import { useLanguage } from '../context/LanguageContext';

interface HeroProps {
  onScrollToElement: (id: string) => void;
}

export default function Hero({ onScrollToElement }: HeroProps) {
  const { t } = useLanguage();

  return (
    <section id="hero" className="relative min-h-[95vh] flex items-center justify-center overflow-hidden bg-brand-dark py-20">
      {/* Background Image with fine luxury overlays */}
      <div className="absolute inset-0 z-0">
        <img
          src={HERO_BACKGROUND}
          alt="The Family Premium Dining"
          className="w-full h-full object-cover object-center scale-105"
          referrerPolicy="no-referrer"
        />
        {/* Dark radial and linear gradients for ultimate text readability & luxurious mood */}
        <div className="absolute inset-0 bg-radial-gradient from-transparent via-brand-dark/40 to-brand-dark/95" />
        <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-brand-dark/50 to-transparent" />
        <div className="absolute inset-0 bg-brand-red/10 mix-blend-color-burn" />
      </div>

      {/* Decorative Traditional Golden Corner Frames */}
      <div className="absolute top-8 left-8 w-12 h-12 border-t-2 border-l-2 border-brand-gold/30 hidden md:block" />
      <div className="absolute top-8 right-8 w-12 h-12 border-t-2 border-r-2 border-brand-gold/30 hidden md:block" />
      <div className="absolute bottom-8 left-8 w-12 h-12 border-b-2 border-l-2 border-brand-gold/30 hidden md:block" />
      <div className="absolute bottom-8 right-8 w-12 h-12 border-b-2 border-r-2 border-brand-gold/30 hidden md:block" />

      {/* Hero Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-brand-beige">
        
        {/* Authentic Badge Indicator */}
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-brand-dark/80 backdrop-blur-md border border-brand-gold/25 mb-8 shadow-xl"
        >
          <span className="flex h-2 w-2 rounded-full bg-brand-green animate-pulse" />
          <p className="text-xs font-mono uppercase tracking-[0.2em] text-brand-beige/90">
            {t('hero.badge')}
          </p>
        </motion.div>

        {/* Catchy headline */}
        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
          className="font-serif text-4xl sm:text-6xl lg:text-7xl font-bold tracking-tight mb-6 text-transparent bg-clip-text bg-gradient-to-b from-white via-brand-beige to-brand-gold"
        >
          {t('hero.titleFirst')} <br />
          <span className="font-serif italic text-brand-gold">{t('hero.titleSecond')}</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.6 }}
          className="max-w-2xl mx-auto text-base sm:text-lg lg:text-xl text-brand-beige/85 mb-10 leading-relaxed font-sans"
        >
          {t('hero.subtitle')}
        </motion.p>

        {/* Action Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="flex flex-col sm:flex-row items-center justify-center gap-5 mb-12"
        >
          {/* Reservation CTA */}
          <button
            onClick={() => onScrollToElement('reservation')}
            className="w-full sm:w-auto flex items-center justify-center gap-3 bg-gradient-to-r from-brand-gold to-yellow-600 hover:from-yellow-600 hover:to-brand-gold text-brand-dark px-8 py-4 rounded-full font-bold text-sm uppercase tracking-wider shadow-lg shadow-brand-gold/20 hover:shadow-brand-gold/45 transform hover:-translate-y-0.5 transition-all duration-300 cursor-pointer"
          >
            <Calendar size={18} />
            {t('hero.btnBook')}
          </button>

          {/* Quick Ordering CTA */}
          <button
            onClick={() => onScrollToElement('menu')}
            className="w-full sm:w-auto flex items-center justify-center gap-3 bg-brand-charcoal/90 hover:bg-brand-gold hover:text-brand-dark text-brand-beige px-8 py-4 rounded-full font-bold text-sm uppercase tracking-wider border border-brand-gold/40 hover:border-brand-gold shadow-lg transform hover:-translate-y-0.5 transition-all duration-300 cursor-pointer"
          >
            <ShoppingBag size={18} />
            {t('hero.btnMenu')}
          </button>
        </motion.div>

        {/* Highlights overlay indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 0.7 }}
          transition={{ delay: 1.2, duration: 1 }}
          className="grid grid-cols-2 md:grid-cols-3 max-w-3xl mx-auto pt-8 border-t border-brand-gold/10 gap-4 text-center text-xs font-mono text-brand-beige/60 uppercase tracking-widest"
        >
          <div className="flex flex-col items-center gap-1.5 py-2">
            <span className="text-brand-gold text-base font-bold">100% Frais</span>
            <span>Ingrédients du Jour</span>
          </div>
          <div className="flex flex-col items-center gap-1.5 py-2 border-l border-brand-gold/15">
            <span className="text-brand-gold text-base font-bold">Traditionnel</span>
            <span>Recettes Ancestrales</span>
          </div>
          <div className="hidden md:flex flex-col items-center gap-1.5 py-2 border-l border-brand-gold/15">
            <span className="text-brand-gold text-base font-bold">1/6 Prachathipatai Rd</span>
            <span>Quartier Phra Nakhon</span>
          </div>
        </motion.div>

        {/* Animated Scroll indicator */}
        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1">
          <motion.button
            onClick={() => onScrollToElement('why-us')}
            animate={{ y: [0, 6, 0] }}
            transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
            className="p-1 rounded-full text-brand-gold hover:bg-brand-gold/10 transition-colors"
          >
            <ArrowDown size={18} />
          </motion.button>
        </div>
      </div>
    </section>
  );
}
