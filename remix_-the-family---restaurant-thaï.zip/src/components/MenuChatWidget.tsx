import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Sparkles, Phone, ShieldAlert, BadgeInfo, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: Date;
}

export default function MenuChatWidget() {
  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputVal, setInputVal] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  const welcomeText = language === 'fr' 
    ? "Sawatdee khrap! Je suis l’assistant virtuel de The Family. Posez-moi vos questions sur nos plats (allergies, sans gluten, végétarien, piquant, etc.) ou notre service !"
    : "Sawatdee khrap! I am The Family's virtual concierge. Ask me anything about our dishes (allergies, gluten-free, spiciness, veggie options) or our lounge!";

  // Suggestion chips
  const suggestionChips = language === 'fr' 
    ? [
        { label: "🌱 Options végétariennes", query: "plats végétariens" },
        { label: "🌾 Sans gluten ?", query: "sans gluten" },
        { label: "🔥 Niveau piquant Tom Yum", query: "tom yum" },
        { label: "📞 Contacter par WhatsApp", query: "whatsapp" },
      ]
    : [
        { label: "🌱 Vegetarian choices", query: "vegetarian dishes" },
        { label: "🌾 Gluten-free options", query: "gluten free" },
        { label: "🔥 Tom Yum spiciness", query: "tom yum" },
        { label: "📞 Connect on WhatsApp", query: "whatsapp" },
      ];

  // Initialize welcome message
  useEffect(() => {
    if (messages.length === 0) {
      setMessages([
        {
          id: 'welcome',
          sender: 'assistant',
          text: welcomeText,
          timestamp: new Date()
        }
      ]);
    }
  }, [language]);

  // Scroll to bottom whenever messages list grows or typing begins
  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping, isOpen]);

  // Natural language processing heuristic for instant premium answers
  const generateResponse = (userQuery: string): string => {
    const query = userQuery.toLowerCase();
    
    // 1. VEGETARIAN / VEGAN
    if (query.includes('végétarien') || query.includes('vege') || query.includes('vegan') || query.includes('sans viande') || query.includes('meatless')) {
      return language === 'fr'
        ? "🌱 Absolument ! Notre menu propose une section 100% végétarienne. Nos spécialités comme le Curry Vert Veggie & Tofu (v1), la soupe aux champignons et le Pad Thaï Veggie (v2) sont très populaires. De plus, nos cuisiniers peuvent adapter de nombreux plats sur demande."
        : "🌱 Absolutely! We have a dedicated 100% Vegetarian section in our menu. Top choices include our Veggie Green Curry with Tofu (v1), mushroom soup, and Veggie Pad Thai (v2). Most of our other dishes can also be prepared with organic crispy tofu upon request.";
    }

    // 2. GLUTEN FREE
    if (query.includes('gluten') || query.includes('sans gluten') || query.includes('coeliaque') || query.includes('allergie')) {
      return language === 'fr'
        ? "🌾 Pour nos convives Coeliaques / Intolérants au gluten : Nous avons des choix sûrs comme notre Som Tam (salade de papaye verte pilée v3), notre Khao Pad ou nos frites de tofu. Nous prenons la contamination croisée très au sérieux, n'hésitez pas à spécifier 'sans gluten' lors de votre commande !"
        : "🌾 For guest convenience: We serve excellent gluten-protected options like our Fresh Som Tam (green papaya salad v3), standard Khao Pad rice, and crispy tofu starters. Please state your dietary requirements in your cart or booking memo so our chef takes utmost care with contamination.";
    }

    // 3. SPICY
    if (query.includes('épicé') || query.includes('piquant') || query.includes('spicy') || query.includes('piment') || query.includes('chili') || query.includes('tom yum') || query.includes('krapow')) {
      return language === 'fr'
        ? "🔥 Le niveau d'épice est sacré chez nous ! Nos Soupes Tom Yum et le fameux Pad-Krapow (m4) sont notés de 1 à 3 piments. Spécifiez lors de l'ajout au panier si vous désirez : 'No Spicy' (doux), 'Thai Style' (piment d'origine), ou 'Mild' (moyen) !"
        : "🔥 We respect traditional spice! Our Tom Yum soup and Pad-Krapow stir-fry (m4) carry indicators between levels 1 and 3. When completing your selection, feel free to add customized notes like 'No Spicy' (very mild), 'Medium Thai' or 'True Bangkok Style'!";
    }

    // 4. WHATSAPP
    if (query.includes('whatsapp') || query.includes('numéro') || query.includes('telephone') || query.includes('tel') || query.includes('phone') || query.includes('contact')) {
      return language === 'fr'
        ? "📞 Pour nous contacter directement sur WhatsApp, cliquez sur l'action rapide de notre bouton flottant ou enregistrez notre hotline : +66 95 896 0395. Notre équipe répond en français, anglais et thaïlandais !"
        : "📞 You can chat with us live on WhatsApp using the Floating Button short-cut, or message/call our direct reservation line directly at +66 95 896 0395. Our team responds in French, English, and Thai!";
    }

    // 5. RESERVATION
    if (query.includes('réserver') || query.includes('reservation') || query.includes('book') || query.includes('place') || query.includes('table')) {
      return language === 'fr'
        ? "📅 Pour bloquer votre table royale, nous vous recommandons d'utiliser notre outil de réservation intelligente au bas de la page. Les confirmations sont faites automatiquement et instantanément. Vous recevrez même un ticket numérique à présenter à votre arrivée !"
        : "📅 To block your table at The Family, please scroll to our smart Reservation utility at the bottom. Booking is fully automated and instantly secure. You will also get a downloadable receipt ticket immediately!";
    }

    // 6. ADRESSE / CONTACT
    if (query.includes('adresse') || query.includes('trouver') || query.includes('address') || query.includes('lieu') || query.includes('bangkok') || query.includes('phra nakhon')) {
      return language === 'fr'
        ? "📍 Nous sommes situés au cœur historique de Bangkok : 1/6 Prachathipatai Road, Phra Nakhon. Une courte distance en Tuk-Tuk depuis Khao San Road ou le Grand Palais !"
        : "📍 You can easily find us in the historical center of Phra Nakhon, Bangkok: 1/6 Prachathipatai Road. Just a brief Tuk-Tuk ride away from Khao San Road or the Grand Palace!";
    }

    // 7. DEFAULT
    return language === 'fr'
      ? "✨ J'ai bien noté votre demande concernant notre carte. Pour de plus amples informations, n'hésitez pas à nous appeler directement au +66 95 896 0395 ou à nous rejoindre sur WhatsApp !"
      : "✨ Thank you for looking into our noble Thai catalog. For customized preparations, please reach our dining managers at +66 95 896 0395 or write to us on WhatsApp!";
  };

  const handleSendMessage = (text: string) => {
    if (!text.trim()) return;

    const userMsg: Message = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    // Simulate answering delay
    setTimeout(() => {
      const respText = generateResponse(text);
      const assistantMsg: Message = {
        id: `msg-reply-${Date.now()}`,
        sender: 'assistant',
        text: respText,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 1200);
  };

  return (
    <>
      {/* Floating Entry Chat circle (if not open) */}
      <AnimatePresence>
        {!isOpen && (
          <motion.button
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            onClick={() => setIsOpen(true)}
            className="fixed bottom-24 right-6 z-40 p-4 rounded-full bg-brand-gold text-brand-dark shadow-2xl border border-brand-gold/20 hover:bg-yellow-500 cursor-pointer flex items-center justify-center group"
            title="Chat en direct / Live Menu Help"
          >
            <MessageSquare size={22} className="group-hover:scale-110 transition-transform" />
            <span className="absolute -top-1.5 -left-1.5 flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-red opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-brand-red border border-white"></span>
            </span>
          </motion.button>
        )}
      </AnimatePresence>

      {/* Embedded/Floating Chat Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            transition={{ duration: 0.25 }}
            className="fixed bottom-6 right-6 z-50 w-[350px] sm:w-[380px] h-[500px] bg-brand-charcoal border border-brand-gold/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col justify-between"
          >
            {/* Header section */}
            <div className="bg-brand-dark p-4 border-b border-brand-gold/15 flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-full bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold">
                  <Sparkles size={16} className="animate-pulse" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-xs sm:text-sm text-brand-beige">
                    The Family Concierge
                  </h4>
                  <div className="flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-[#2E8B57] inline-block animate-pulse" />
                    <span className="text-[9px] font-mono text-emerald-500 uppercase">{language === 'fr' ? 'Menu intelligent' : 'Smart advisor'}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => setIsOpen(false)}
                className="text-brand-gold hover:bg-brand-gold/10 p-1 rounded transition-colors cursor-pointer"
              >
                <X size={16} />
              </button>
            </div>

            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-[#161616]">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 text-xs leading-relaxed ${
                      m.sender === 'user'
                        ? 'bg-brand-gold text-brand-dark font-medium rounded-tr-none'
                        : 'bg-brand-charcoal border border-brand-gold/10 text-brand-beige rounded-tl-none'
                    }`}
                  >
                    <p className="whitespace-pre-line">{m.text}</p>
                    <span className="block text-[8px] opacity-40 text-right mt-1.5 font-mono">
                      {m.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))}

              {isTyping && (
                <div className="flex justify-start">
                  <div className="bg-brand-charcoal border border-brand-gold/10 rounded-2xl rounded-tl-none px-4 py-3 flex gap-1 items-center">
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-gold/50 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-gold/70 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-1.5 h-1.5 rounded-full bg-brand-gold animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                </div>
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Suggestions list */}
            {messages.length === 1 && (
              <div className="bg-brand-dark/50 p-2 border-t border-brand-gold/5 overflow-x-auto whitespace-nowrap flex gap-1.5 select-none scrollbar-none">
                {suggestionChips.map((chip, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSendMessage(chip.query)}
                    className="inline-block px-3 py-1.5 rounded-full bg-brand-charcoal border border-brand-gold/10 text-[10px] text-brand-gold hover:bg-brand-gold hover:text-brand-dark transition-all cursor-pointer font-sans"
                  >
                    {chip.label}
                  </button>
                ))}
              </div>
            )}

            {/* Input Form footer */}
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage(inputVal);
              }}
              className="p-3 bg-brand-dark border-t border-brand-gold/15 flex gap-2"
            >
              <input
                type="text"
                placeholder={language === 'fr' ? "Écrivez votre message..." : "Ask your query..."}
                value={inputVal}
                onChange={(e) => setInputVal(e.target.value)}
                className="flex-1 bg-brand-charcoal border border-brand-gold/15 rounded-xl px-3.5 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold/50 font-sans text-wrap"
              />
              <button
                type="submit"
                className="bg-brand-gold text-brand-dark p-2.5 rounded-xl hover:bg-yellow-500 cursor-pointer flex items-center justify-center transition-colors shrink-0"
              >
                <Send size={14} className="fill-brand-dark" />
              </button>
            </form>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
