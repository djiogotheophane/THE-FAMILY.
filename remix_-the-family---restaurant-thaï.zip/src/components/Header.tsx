import React, { useState } from 'react';
import { ShoppingBag, Calendar, Menu as MenuIcon, X, Phone, Star, ChevronDown, Globe } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';
import { LANGUAGES } from '../translations';

interface HeaderProps {
  onOpenCart: () => void;
  cartCount: number;
  onScrollToElement: (id: string) => void;
  activeSection: string;
}

export default function Header({ onOpenCart, cartCount, onScrollToElement, activeSection }: HeaderProps) {
  const { language, setLanguage, t } = useLanguage();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [langMenuOpen, setLangMenuOpen] = useState(false);
  const [mobileLangOpen, setMobileLangOpen] = useState(false);

  const navLinks = [
    { label: t('nav.home'), id: 'hero' },
    { label: t('nav.specialties'), id: 'specialties' },
    { label: t('nav.menu'), id: 'menu' },
    { label: t('nav.history'), id: 'history' },
    { label: t('nav.gallery'), id: 'gallery' },
    { label: t('nav.reservation'), id: 'reservation' },
    { label: t('nav.contact'), id: 'contact' },
  ];

  const handleLinkClick = (id: string) => {
    onScrollToElement(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-brand-dark/95 backdrop-blur-md border-b border-brand-gold/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo / Brand */}
          <div className="flex items-center gap-3">
            <button 
              onClick={() => handleLinkClick('hero')} 
              className="group text-left"
            >
              <div className="flex items-center gap-2">
                <span className="font-serif text-2xl font-bold tracking-widest text-brand-gold group-hover:text-brand-orange transition-colors duration-300">
                  THE FAMILY
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 text-[9px] bg-brand-gold/15 text-brand-gold rounded font-mono border border-brand-gold/20 uppercase tracking-widest">
                  {t('nav.premiumTag')}
                </span>
              </div>
              <p className="text-[10px] uppercase font-mono tracking-[0.25em] text-brand-beige/50 group-hover:text-brand-gold/70 transition-colors">
                {t('nav.subLogo')}
              </p>
            </button>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleLinkClick(link.id)}
                className={`text-sm tracking-wide font-medium uppercase relative py-2 transition-all duration-300 ${
                  activeSection === link.id
                    ? 'text-brand-gold font-semibold'
                    : 'text-brand-beige/80 hover:text-brand-gold'
                }`}
              >
                {link.label}
                {activeSection === link.id && (
                  <motion.div
                    layoutId="activeIndicator"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-brand-gold rounded-full"
                    transition={{ type: 'spring', stiffness: 380, damping: 30 }}
                  />
                )}
              </button>
            ))}
          </nav>

          {/* Right actions */}
          <div className="flex items-center gap-4">
            {/* Language Switcher Dropdown */}
            <div className="relative">
              <button
                onClick={() => setLangMenuOpen(!langMenuOpen)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-full bg-brand-gold/5 border border-brand-gold/15 text-brand-beige text-xs font-semibold hover:border-brand-gold/40 transition-all cursor-pointer"
                title="Change language / Changer de langue / เปลี่ยนภาษา"
              >
                <span className="text-sm mr-0.5">{LANGUAGES.find(l => l.code === language)?.flag}</span>
                <span className="uppercase text-[10px] font-mono tracking-wider">{language}</span>
                <ChevronDown size={11} className={`text-brand-gold/70 transition-transform ${langMenuOpen ? 'rotate-180' : ''}`} />
              </button>

              <AnimatePresence>
                {langMenuOpen && (
                  <>
                    {/* Backdrop to dismiss */}
                    <div className="fixed inset-0 z-40" onClick={() => setLangMenuOpen(false)} />
                    <motion.div
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 mt-2 w-44 rounded-xl bg-brand-charcoal border border-brand-gold/30 shadow-2xl overflow-hidden py-1.5 z-50 max-h-72 overflow-y-auto"
                    >
                      <div className="px-2.5 pb-1 mb-1 border-b border-brand-gold/10 text-[9px] font-sans text-brand-gold uppercase tracking-wider font-bold">
                        Select Language
                      </div>
                      {LANGUAGES.map((l) => (
                        <button
                          key={l.code}
                          onClick={() => {
                            setLanguage(l.code);
                            setLangMenuOpen(false);
                          }}
                          className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs transition-colors hover:bg-brand-gold/10 hover:text-brand-gold ${
                            language === l.code ? 'bg-brand-gold/10 text-brand-gold font-bold' : 'text-brand-beige/80'
                          }`}
                        >
                          <span className="flex items-center gap-2">
                            <span className="text-sm shrink-0">{l.flag}</span>
                            <span>{l.nativeName}</span>
                          </span>
                          {language === l.code && <span className="text-[10px] text-brand-gold font-mono">●</span>}
                        </button>
                      ))}
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>

            {/* Phone Quick Link */}
            <a 
              href="tel:+66958960395" 
              className="hidden md:flex items-center gap-2 text-xs font-mono text-brand-gold/80 hover:text-brand-gold bg-brand-gold/5 px-3 py-1.5 rounded-full border border-brand-gold/10 transition-colors"
            >
              <Phone size={13} />
              <span>+66 95 896 0395</span>
            </a>

            {/* Cart Button */}
            <button
              onClick={onOpenCart}
              className="relative p-2.5 rounded-full bg-brand-gold/10 text-brand-gold border border-brand-gold/20 hover:bg-brand-gold hover:text-brand-dark transition-all duration-300 cursor-pointer group"
              aria-label={t('nav.cart')}
            >
              <ShoppingBag size={18} className="group-hover:scale-110 transition-transform" />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center bg-brand-red text-white text-[10px] font-bold rounded-full border border-brand-dark animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Quick Reservation CTA */}
            <button
              onClick={() => handleLinkClick('reservation')}
              className="hidden sm:flex items-center gap-2 bg-gradient-to-r from-brand-gold to-yellow-600 hover:from-yellow-600 hover:to-brand-gold text-brand-dark text-xs font-bold uppercase tracking-wider py-2.5 px-5 rounded-full shadow-lg hover:shadow-brand-gold/20 transition-all duration-300 transform hover:-translate-y-0.5 font-sans"
            >
              <Calendar size={14} />
              {t('nav.bookTable')}
            </button>

            {/* Mobile Nav Toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-brand-gold bg-brand-gold/5 rounded hover:bg-brand-gold/15 border border-brand-gold/10 transition-colors"
              aria-label="Ouvrir le menu"
            >
              {mobileMenuOpen ? <X size={20} /> : <MenuIcon size={20} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile nav dropdown */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-brand-charcoal border-b border-brand-gold/10"
          >
            <div className="px-4 pt-2 pb-6 space-y-2">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => handleLinkClick(link.id)}
                  className={`block w-full text-left px-4 py-3 rounded-lg text-base font-medium transition-colors ${
                    activeSection === link.id
                      ? 'bg-brand-gold/10 text-brand-gold border-l-4 border-brand-gold'
                      : 'text-brand-beige/80 hover:bg-brand-gold/5 hover:text-brand-gold'
                  }`}
                >
                  {link.label}
                </button>
              ))}

              <div className="pt-4 border-t border-brand-gold/10 flex flex-col gap-3 px-4">
                {/* Mobile Language Switcher inline */}
                <div className="space-y-2">
                  <button
                    onClick={() => setMobileLangOpen(!mobileLangOpen)}
                    className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg border border-brand-gold/10 bg-brand-dark text-brand-beige text-xs"
                  >
                    <span className="flex items-center gap-2 font-bold text-brand-gold">
                      <Globe size={14} />
                      <span>Language: {LANGUAGES.find(l => l.code === language)?.nativeName}</span>
                    </span>
                    <span className="text-xl">{LANGUAGES.find(l => l.code === language)?.flag}</span>
                  </button>

                  <AnimatePresence>
                    {mobileLangOpen && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: 'auto' }}
                        exit={{ opacity: 0, height: 0 }}
                        className="grid grid-cols-2 gap-2 bg-brand-dark/50 p-2 rounded-lg border border-brand-gold/5 max-h-48 overflow-y-auto"
                      >
                        {LANGUAGES.map((l) => (
                          <button
                            key={l.code}
                            onClick={() => {
                              setLanguage(l.code);
                              setMobileLangOpen(false);
                            }}
                            className={`flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-colors ${
                              language === l.code ? 'bg-brand-gold text-brand-dark font-bold' : 'text-brand-beige/70 hover:bg-brand-gold/5'
                            }`}
                          >
                            <span>{l.flag}</span>
                            <span className="truncate">{l.nativeName}</span>
                          </button>
                        ))}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <a 
                  href="tel:+66958960395" 
                  className="flex items-center gap-3 text-sm font-mono text-brand-beige"
                >
                  <Phone size={14} className="text-brand-gold" />
                  +66 95 896 0395
                </a>
                <button
                  onClick={() => handleLinkClick('reservation')}
                  className="w-full flex items-center justify-center gap-2 bg-brand-gold text-brand-dark font-bold uppercase tracking-wider py-3 px-4 rounded-lg text-sm"
                >
                  <Calendar size={15} />
                  {t('nav.bookTable')}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
