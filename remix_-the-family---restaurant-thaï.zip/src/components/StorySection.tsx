import React from 'react';
import { Compass, ShieldCheck } from 'lucide-react';
import { PHOTO_PLACEHOLDERS } from '../data';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function StorySection() {
  const { t, language } = useLanguage();

  return (
    <section id="history" className="py-24 bg-brand-charcoal relative overflow-hidden">
      {/* Absolute decorative backdrops */}
      <div className="absolute left-0 top-0 w-full h-full bg-[radial-gradient(ellipse_at_30%_50%,rgba(139,0,0,0.06),transparent_50%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
          
          {/* Story Illustrations on Left (6 cols of 12) */}
          <div className="lg:col-span-6 relative">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-4">
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6 }}
                  className="rounded-2xl overflow-hidden shadow-2xl h-60 border border-brand-gold/10"
                >
                  <img 
                    src={PHOTO_PLACEHOLDERS.teamCocktail} 
                    alt="The Family Team" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.2 }}
                  className="rounded-2xl overflow-hidden shadow-2xl h-44 relative group border border-brand-gold/10"
                >
                  <img 
                    src={PHOTO_PLACEHOLDERS.thaiMarket} 
                    alt="Fresh herbs market" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-brand-dark/40 group-hover:bg-transparent transition-colors" />
                </motion.div>
              </div>

              <div className="space-y-4 pt-8">
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.1 }}
                  className="rounded-2xl overflow-hidden shadow-2xl h-44 border border-brand-gold/10"
                >
                  <img 
                    src={PHOTO_PLACEHOLDERS.restaurantInterior} 
                    alt="The Family Kitchen" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
                <motion.div 
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.3 }}
                  className="rounded-2xl overflow-hidden shadow-2xl h-60 border border-brand-gold/10"
                >
                  <img 
                    src={PHOTO_PLACEHOLDERS.seafood} 
                    alt="Thai Traditional Dish Cooking" 
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </motion.div>
              </div>
            </div>

            {/* Slogan card overlapping images */}
            <div className="absolute bottom-6 left-6 right-6 md:left-24 md:right-24 bg-brand-dark/95 backdrop-blur border border-brand-gold/30 p-5 rounded-2xl shadow-2xl">
              <p className="font-serif italic text-brand-gold text-lg text-center font-bold">
                {language === 'fr' ? '" L\'authenticité de la Thaïlande dans chaque assiette. "' : '" Genuine Thai flavors crafted in every detail. "'}
              </p>
            </div>
          </div>

          {/* Core storytelling Copy on Right (6 cols of 12) */}
          <div className="lg:col-span-6 space-y-6">
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
              {t('history.badge')}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-beige tracking-tight leading-tight">
              {t('history.title')}
            </h2>
            <div className="w-12 h-0.5 bg-brand-gold" />

            <div className="space-y-4 text-brand-beige/80 text-sm sm:text-base leading-relaxed font-sans">
              <p>
                {t('history.p1')}
              </p>
              <p>
                {t('history.p2')}
              </p>
              <p className="font-serif italic text-brand-gold text-right font-medium">
                {t('history.signature')}
              </p>
            </div>

            {/* Cultural highlights indicators */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded bg-brand-gold/10 border border-brand-gold/20 text-brand-gold shrink-0">
                  <Compass size={16} />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-brand-beige">
                    {language === 'fr' ? 'Quartier Historique' : 'Historic District'}
                  </h4>
                  <p className="text-xs text-brand-beige/60 mt-0.5">
                    {language === 'fr' ? 'Phra Nakhon, berceau de la culture.' : 'Phra Nakhon, birthplace of culture.'}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="p-2 rounded bg-brand-gold/10 border border-brand-gold/20 text-brand-gold shrink-0">
                  <ShieldCheck size={16} />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-sm text-brand-beige">
                    {language === 'fr' ? 'Secrets Gardés' : 'Sacred Secrets'}
                  </h4>
                  <p className="text-xs text-brand-beige/60 mt-0.5">
                    {language === 'fr' ? 'Recettes transmises avec dévotion.' : 'Formulas handed down with devotion.'}
                  </p>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
