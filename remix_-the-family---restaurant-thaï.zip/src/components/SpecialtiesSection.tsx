import React, { useState } from 'react';
import { Flame, Star, ShoppingCart, Info, Sparkles, Check } from 'lucide-react';
import { MenuItem } from '../types';
import { MENU_ITEMS } from '../data';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface SpecialtiesSectionProps {
  onAddToCart: (item: MenuItem, selectedOption?: string) => void;
  onViewDish?: (item: MenuItem) => void;
}

export default function SpecialtiesSection({ onAddToCart, onViewDish }: SpecialtiesSectionProps) {
  const { t, language } = useLanguage();
  
  // Extract specialties or star items
  const specialties = MENU_ITEMS.filter(it => 
    ['m1', 'm2', 's2', 'd1', 'm4', 's3', 'm7', 'b1'].includes(it.id)
  );

  // Highlighting active dish details in a mini interactive drawer/overlay for customized protein additions or single-click quick buy
  const [activeCustomizingItem, setActiveCustomizingItem] = useState<MenuItem | null>(null);
  const [selectedProtein, setSelectedProtein] = useState<string>('Poulet (Traditionnel)');
  const [showNotification, setShowNotification] = useState<string | null>(null);

  const proteinOptions = [
    { label: language === 'fr' ? 'Poulet fermier' : 'Farmhouse Chicken', priceMod: 0 },
    { label: language === 'fr' ? 'Crevettes tigrées géantes' : 'Giant Tiger Prawns', priceMod: 60 },
    { label: language === 'fr' ? 'Bœuf de Chiang Mai' : 'Chiang Mai Beef', priceMod: 40 },
    { label: language === 'fr' ? 'Tofu biologique croustillant' : 'Crispy Organic Tofu', priceMod: -20 },
  ];

  const handleStartQuickOrder = (item: MenuItem) => {
    // If it has customizable tags or is main/curry, let them choose protein, otherwise direct add
    if (item.category === 'mains' || item.id === 's2') {
      setSelectedProtein(language === 'fr' ? 'Poulet fermier' : 'Farmhouse Chicken');
      setActiveCustomizingItem(item);
    } else {
      onAddToCart(item);
      triggerNotification(language === 'fr' ? item.name : (item.englishName || item.name));
    }
  };

  const handleConfirmCustomOrder = () => {
    if (!activeCustomizingItem) return;
    
    // Pass selected option cleanly
    onAddToCart(activeCustomizingItem, selectedProtein);
    const displayName = language === 'fr' ? activeCustomizingItem.name : (activeCustomizingItem.englishName || activeCustomizingItem.name);
    triggerNotification(`${displayName} (${selectedProtein})`);
    setActiveCustomizingItem(null);
  };

  const triggerNotification = (dishName: string) => {
    setShowNotification(dishName);
    setTimeout(() => {
      setShowNotification(null);
    }, 2800);
  };

  const getSpicyLabel = (level: number) => {
    if (level === 3) return t('specialties.spicy3');
    if (level === 2) return t('specialties.spicy2');
    if (level === 1) return t('specialties.spicy1');
    return t('specialties.spicy0');
  };

  return (
    <section id="specialties" className="py-24 bg-brand-dark relative overflow-hidden">
      {/* Sparkles background elements */}
      <div className="absolute left-10 top-1/4 w-72 h-72 bg-brand-red/10 blur-[90px] rounded-full pointer-events-none" />
      <div className="absolute right-10 bottom-1/4 w-72 h-72 bg-brand-gold/10 blur-[90px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-16 gap-4">
          <div>
            <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
              {t('specialties.badge')}
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-beige mt-2 tracking-tight">
              {t('specialties.title').split(' ').slice(0, -1).join(' ')} <span className="italic font-serif text-brand-gold">{t('specialties.title').split(' ').slice(-1)}</span>
            </h2>
          </div>
          <div className="flex items-center gap-1.5 self-start md:self-end bg-brand-gold/5 border border-brand-gold/20 px-4 py-2 rounded-lg text-xs text-brand-gold font-mono uppercase tracking-wider">
            <Sparkles size={14} className="animate-spin text-brand-gold" />
            {t('nav.premiumTag')} — Phra Nakhon
          </div>
        </div>

        {/* Speciality Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {specialties.map((item) => {
            const itemDisplayName = language === 'fr' ? item.name : (item.englishName || item.name);
            const secondaryName = language === 'fr' ? item.englishName : item.name;

            return (
              <motion.div
                key={item.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4 }}
                className="bg-brand-charcoal/80 rounded-2xl border border-brand-gold/10 overflow-hidden flex flex-col justify-between group shadow-lg hover:shadow-2xl hover:border-brand-gold/30 transition-all duration-300"
              >
                {/* Image & Price Overlay */}
                <div 
                  onClick={() => onViewDish?.(item)}
                  className="relative h-56 overflow-hidden cursor-pointer"
                  title={language === 'fr' ? 'Cliquer pour voir la composition du plat et la vidéo' : 'Click to view composition & cooking video'}
                >
                  <img
                    src={item.image}
                    alt={itemDisplayName}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-brand-dark/40 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity z-10">
                    <span className="bg-brand-gold/95 text-brand-dark px-3 py-1.5 rounded-full text-[10px] font-mono uppercase font-black tracking-wider shadow">
                      Detail 🔎
                    </span>
                  </div>
                  
                  {/* Spicy Flame badge overlay */}
                  {item.spicyLevel > 0 && (
                    <div className="absolute top-4 left-4 flex gap-0.5 bg-brand-dark/85 backdrop-blur px-2.5 py-1.5 rounded-full border border-brand-red/35 z-10 text-[10px] items-center font-mono" title={getSpicyLabel(item.spicyLevel)}>
                      <span className="text-brand-red font-semibold mr-1">{getSpicyLabel(item.spicyLevel).toUpperCase()}</span>
                      {Array.from({ length: item.spicyLevel }).map((_, i) => (
                        <Flame key={i} size={11} className="text-brand-red fill-brand-red" />
                      ))}
                    </div>
                  )}

                  {/* Tags */}
                  {item.tags.includes('best-seller') && (
                    <div className="absolute top-4 right-4 bg-brand-gold text-brand-dark text-[9px] font-mono uppercase tracking-widest font-black px-2.5 py-1.5 rounded-full shadow-lg z-10">
                      N°1 VENTES
                    </div>
                  )}
                  
                  {item.tags.includes('vegetarian') && item.spicyLevel === 0 && (
                    <div className="absolute top-4 right-4 bg-brand-green/90 text-white text-[9px] font-mono uppercase tracking-widest font-black px-2.5 py-1.5 rounded-full shadow-lg z-10">
                      VEGGIE
                    </div>
                  )}

                  {/* Ambient shade */}
                  <div className="absolute inset-0 bg-gradient-to-t from-brand-charcoal via-transparent to-transparent opacity-60" />
                  
                  {/* Price tag */}
                  <div className="absolute bottom-4 right-4 bg-brand-dark/90 backdrop-blur px-3 py-1.5 rounded-lg border border-brand-gold/30">
                    <span className="font-serif text-brand-gold font-bold">{item.price} ฿</span>
                    <span className="text-[10px] text-brand-beige/40 ml-1">~{(item.price / 36).toFixed(1)}€</span>
                  </div>
                </div>

                {/* Dish Metadata */}
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-1 mb-1.5">
                      <h3 
                        onClick={() => onViewDish?.(item)}
                        className="font-serif text-lg font-bold text-brand-beige group-hover:text-brand-gold transition-colors line-clamp-1 cursor-pointer"
                        title={language === 'fr' ? 'Cliquer pour voir la composition du plat et la vidéo' : 'Click to view composition & cooking video'}
                      >
                        {itemDisplayName}
                      </h3>
                    </div>
                    {secondaryName && (
                      <p className="text-[10px] font-mono uppercase tracking-wider text-brand-gold/60 mb-3.5">
                        {secondaryName}
                      </p>
                    )}
                    <p className="text-xs text-brand-beige/70 leading-relaxed font-sans line-clamp-3 mb-6">
                      {item.description}
                    </p>
                  </div>

                  {/* Add to cart action button */}
                  <button
                    onClick={() => handleStartQuickOrder(item)}
                    className="w-full flex items-center justify-center gap-2.5 py-3 rounded-xl border border-brand-gold/25 bg-brand-gold/5 text-xs font-mono uppercase tracking-widest text-brand-gold hover:bg-brand-gold hover:text-brand-dark hover:border-brand-gold transition-all duration-300 cursor-pointer"
                  >
                    <ShoppingCart size={13} />
                    {t('menu.addCart')}
                  </button>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Dynamic Notification Toast */}
        <AnimatePresence>
          {showNotification && (
            <motion.div
              initial={{ opacity: 0, y: 50, x: '-50%' }}
              animate={{ opacity: 1, y: 0, x: '-50%' }}
              exit={{ opacity: 0, y: 20, x: '-50%' }}
              className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-brand-green border border-emerald-500 text-white px-5 py-3 rounded-full shadow-2xl font-sans text-xs font-medium"
            >
              <Check size={14} className="bg-white/10 p-0.5 rounded-full" />
              <span>{t('specialties.addedSuccess')} : <strong>{showNotification}</strong></span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Protein Customization Overlay Dialog */}
        <AnimatePresence>
          {activeCustomizingItem && (
            <div className="fixed inset-0 bg-brand-dark/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-brand-charcoal rounded-2xl border border-brand-gold/30 p-6 md:p-8 max-w-md w-full relative"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="text-[10px] font-mono text-brand-gold uppercase tracking-widest">
                      {t('menu.customization') || "Customisation"}
                    </span>
                    <h3 className="font-serif text-xl font-bold text-brand-beige">
                      {language === 'fr' ? activeCustomizingItem.name : (activeCustomizingItem.englishName || activeCustomizingItem.name)}
                    </h3>
                  </div>
                  <button
                    onClick={() => setActiveCustomizingItem(null)}
                    className="p-1 rounded bg-brand-gold/10 hover:bg-brand-gold/20 text-brand-gold hover:text-brand-beige text-xs"
                  >
                    X
                  </button>
                </div>

                <p className="text-xs text-brand-beige/70 mb-6 font-sans">
                  {t('menu.customization') || "Protéines au choix :"}
                </p>

                {/* Protein check list */}
                <div className="space-y-3 mb-8">
                  {proteinOptions.map((opt) => (
                    <button
                      key={opt.label}
                      onClick={() => setSelectedProtein(opt.label)}
                      className={`w-full flex items-center justify-between p-3.5 rounded-xl border text-xs font-sans transition-all text-left ${
                        selectedProtein === opt.label
                          ? 'border-brand-gold bg-brand-gold/10 text-brand-gold font-bold'
                          : 'border-brand-gold/15 bg-brand-dark/45 text-brand-beige/80 hover:bg-brand-gold/5'
                      }`}
                    >
                      <span>{opt.label}</span>
                      <span className="font-mono text-xs">
                        {opt.priceMod === 0 
                          ? (language === 'fr' ? 'Inclus' : 'Included') 
                          : opt.priceMod > 0 
                            ? `+${opt.priceMod} ฿` 
                            : `${opt.priceMod} ฿`
                        }
                      </span>
                    </button>
                  ))}
                </div>

                {/* Action trigger */}
                <div className="flex gap-4">
                  <button
                    onClick={() => setActiveCustomizingItem(null)}
                    className="w-1/2 py-3 rounded-lg border border-brand-gold/25 font-mono text-xs uppercase text-brand-beige/70 hover:bg-brand-gold/5"
                  >
                    {language === 'fr' ? 'Annuler' : 'Cancel'}
                  </button>
                  <button
                    onClick={handleConfirmCustomOrder}
                    className="w-1/2 py-3 rounded-lg bg-brand-gold text-brand-dark font-bold font-mono text-xs uppercase tracking-wider"
                  >
                    {language === 'fr' ? 'Ajouter' : 'Add'} {(activeCustomizingItem.price + (proteinOptions.find(o => o.label === selectedProtein)?.priceMod || 0))} ฿
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
