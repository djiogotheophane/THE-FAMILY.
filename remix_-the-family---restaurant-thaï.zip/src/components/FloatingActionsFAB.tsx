import React, { useState, useEffect } from 'react';
import { Sun, Moon, Phone, Calendar, ArrowUp, Plus, Sparkles, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function FloatingActionsFAB() {
  const { language } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Initialize theme from localstorage or system pref
  useEffect(() => {
    const savedTheme = localStorage.getItem('the_family_theme') as 'dark' | 'light' | null;
    const documentElement = document.documentElement;

    if (savedTheme) {
      setTheme(savedTheme);
      if (savedTheme === 'light') {
        documentElement.classList.add('light');
      } else {
        documentElement.classList.remove('light');
      }
    } else {
      // Default to dark for luxurious initial branding feel
      setTheme('dark');
      documentElement.classList.remove('light');
    }

    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 300);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleTheme = () => {
    const nextTheme = theme === 'dark' ? 'light' : 'dark';
    const documentElement = document.documentElement;

    if (nextTheme === 'light') {
      documentElement.classList.add('light');
    } else {
      documentElement.classList.remove('light');
    }

    setTheme(nextTheme);
    localStorage.setItem('the_family_theme', nextTheme);
  };

  const handleScrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
    setIsOpen(false);
  };

  const menuItems = [
    {
      id: 'theme',
      icon: theme === 'dark' ? <Sun size={15} /> : <Moon size={15} />,
      label: theme === 'dark' ? (language === 'fr' ? 'Mode Jour ☀️' : 'Day Mode ☀️') : (language === 'fr' ? 'Mode Nuit 🌙' : 'Night Mode 🌙'),
      action: toggleTheme,
      bg: 'bg-amber-500 hover:bg-amber-600 border-amber-400/20 text-white',
    },
    {
      id: 'whatsapp',
      icon: (
        <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.004 5.232 5.234 0 11.661 0c3.112.001 6.04 1.212 8.243 3.417 2.204 2.204 3.414 5.132 3.414 8.245-.004 6.425-5.234 11.656-11.663 11.656-2.001-.001-3.97-.514-5.716-1.493L0 24zm6.09-3.957c1.6.95 3.1 1.455 4.861 1.456 5.371 0 9.743-4.373 9.746-9.743.002-2.602-1.01-5.05-2.859-6.897C16.1 2.996 13.623 1.95 11.026 1.95c-5.385 0-9.766 4.382-9.769 9.75-.001 1.83.49 3.614 1.422 5.174l-.934 3.415 3.504-.919zm12.091-7.147c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.669.149-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.462-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.521.151-.172.2-.296.3-.495.099-.198.05-.371-.025-.521-.075-.148-.669-1.611-.916-2.206-.242-.579-.487-.501-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.263.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.719 2.006-1.413.248-.695.248-1.29.173-1.414-.075-.124-.272-.198-.57-.347z"/></svg>
      ),
      label: language === 'fr' ? 'WhatsApp Direct' : 'WhatsApp Us',
      action: () => {
        window.open('https://wa.me/66958960395?text=Sawatdee%20ka%20-%20The%20Family%20Bangkok', '_blank');
        setIsOpen(false);
      },
      bg: 'bg-emerald-600 hover:bg-emerald-700 border-emerald-500/20 text-white',
    },
    {
      id: 'call',
      icon: <Phone size={15} />,
      label: language === 'fr' ? 'Appeler Hotline' : 'Call Hotline',
      action: () => {
        window.location.href = 'tel:+66958960395';
        setIsOpen(false);
      },
      bg: 'bg-sky-600 hover:bg-sky-700 border-sky-500/20 text-white',
    },
    {
      id: 'book',
      icon: <Calendar size={15} />,
      label: language === 'fr' ? 'Réserver Table' : 'Table Booking',
      action: () => handleScrollToSection('reservation'),
      bg: 'bg-brand-gold hover:bg-yellow-600 border-brand-gold/20 text-brand-dark',
    },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-center gap-3">
      {/* Scroll to Top element placed cleanly right above the FAB expansion */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 10 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="p-3.5 rounded-full bg-brand-charcoal text-brand-gold border border-brand-gold/30 hover:bg-brand-gold hover:text-brand-dark transition-all duration-300 shadow-xl cursor-pointer"
            title={language === 'fr' ? 'Retour en haut' : 'Back to Top'}
          >
            <ArrowUp size={15} className="animate-bounce" />
          </motion.button>
        )}
      </AnimatePresence>

      <div className="relative flex flex-col items-center">
        {/* Floating elements expansion items */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
              className="absolute bottom-16 flex flex-col items-center gap-2.5 pb-2 min-w-[160px]"
            >
              {menuItems.map((item, index) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.04 }}
                  className="flex items-center gap-2 justify-end w-full group select-none"
                >
                  <span className="opacity-0 group-hover:opacity-100 bg-brand-dark/95 border border-brand-gold/25 px-2.5 py-1 rounded-lg text-[9px] font-mono text-brand-gold uppercase tracking-wider transition-opacity shadow duration-200">
                    {item.label}
                  </span>
                  <button
                    onClick={item.action}
                    className={`p-3 rounded-full border shadow-2xl transition-all duration-300 transform hover:-translate-y-0.5 cursor-pointer shrink-0 ${item.bg}`}
                    aria-label={item.label}
                  >
                    {item.icon}
                  </button>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Master floating trigger circle */}
        <motion.button
          onClick={() => setIsOpen(!isOpen)}
          className={`relative p-4 rounded-full shadow-2xl border flex items-center justify-center transition-all duration-300 cursor-pointer ${
            isOpen 
              ? 'bg-brand-gold text-brand-dark border-brand-gold' 
              : 'bg-brand-gold text-brand-dark border-brand-gold/30 hover:scale-105'
          }`}
          aria-expanded={isOpen}
          title="Quick Actions"
        >
          {/* Subtle decoration accent spinner */}
          <span className="absolute inset-0 rounded-full border border-dashed border-brand-dark/20 animate-spin" style={{ animationDuration: '10s' }} />
          
          <motion.div
            animate={{ rotate: isOpen ? 135 : 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
          >
            <Plus size={20} className="stroke-[2.5px]" />
          </motion.div>
        </motion.button>
      </div>
    </div>
  );
}
