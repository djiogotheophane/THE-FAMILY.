import React from 'react';
import { Clock, MapPin, Phone, MessageSquareCode, Mail, Share2, Instagram, Facebook, Globe, Star } from 'lucide-react';
import ReviewsSection from './ReviewsSection';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function MapContactSection() {
  const { t, language } = useLanguage();

  const daysTranslation: Record<string, Record<string, string>> = {
    fr: {
      Monday: 'Lundi', Tuesday: 'Mardi', Wednesday: 'Mercredi', Thursday: 'Jeudi', Friday: 'Vendredi', Saturday: 'Samedi', Sunday: 'Dimanche',
      Continuous: 'Continu', Limited: 'Réduit', Closed: 'Fermé'
    },
    en: {
      Monday: 'Monday', Tuesday: 'Tuesday', Wednesday: 'Wednesday', Thursday: 'Thursday', Friday: 'Friday', Saturday: 'Saturday', Sunday: 'Sunday',
      Continuous: 'Continuous', Limited: 'Reduced', Closed: 'Closed'
    }
  };

  const getLabel = (key: string) => {
    const lang = (language === 'fr' || language === 'en') ? language : 'fr';
    return daysTranslation[lang][key] || key;
  };

  const openingHours = [
    { day: getLabel('Monday'), time: language === 'fr' ? '12h00 – 22h00' : '12:00 PM – 10:00 PM', status: getLabel('Continuous') },
    { day: getLabel('Tuesday'), time: language === 'fr' ? '12h00 – 17h00' : '12:00 PM – 5:00 PM', status: getLabel('Limited') },
    { day: getLabel('Wednesday'), time: language === 'fr' ? 'Fermé' : 'Closed', status: getLabel('Closed'), isClosed: true },
    { day: getLabel('Thursday'), time: language === 'fr' ? '12h00 – 22h00' : '12:00 PM – 10:00 PM', status: getLabel('Continuous') },
    { day: getLabel('Friday'), time: language === 'fr' ? '12h00 – 22h00' : '12:00 PM – 10:00 PM', status: getLabel('Continuous') },
    { day: getLabel('Samedi'), time: language === 'fr' ? '12h00 – 22h00' : '12:00 PM – 10:00 PM', status: getLabel('Continuous') },
    { day: getLabel('Dimanche'), time: language === 'fr' ? '12h00 – 22h00' : '12:00 PM – 10:00 PM', status: getLabel('Continuous') },
  ];

  // Raw public Google Map Search Location query embed (requires no API key)
  const mapEmbedUrl = "https://maps.google.com/maps?q=The%20Family%201/6%20Prachathipatai%20Road,%20Phra%20Nakhon,%20Bangkok,%20Thailand&t=&z=16&ie=UTF8&iwloc=&output=embed";

  return (
    <section id="contact" className="py-24 bg-brand-dark relative overflow-hidden">
      <div className="absolute left-10 top-1/2 w-80 h-80 bg-brand-red/5 blur-[100px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
            – {language === 'fr' ? 'Venez-nous Voir' : 'Come See Us'}
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-beige mt-2 tracking-tight">
            {language === 'fr' ? 'Avis, Horaires & Adresse' : 'Reviews, Hours & Location'}
          </h2>
          <div className="w-12 h-0.5 bg-brand-gold mx-auto mt-6" />
          <p className="text-xs sm:text-sm text-brand-beige/65 mt-4 leading-relaxed font-sans">
            {language === 'fr' 
              ? "Situé au cœur de la ceinture culturelle de Bangkok, The Family est accessible depuis le Grand Palais et Khao San Road. Rejoignez notre table d'exception." 
              : "Nestled in Bangkok's historical sanctuary, The Family is situated close to the Grand Palace and Khao San Road. Welcome to our table."}
          </p>
        </div>

        {/* Dynamic Reviews Section Segment first! */}
        <div className="mb-24">
          <ReviewsSection />
        </div>

        {/* Grid holding Map, Hours, Details */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 pt-12 border-t border-brand-gold/10">
          
          {/* Detailed Info left (4 cols of 12) */}
          <div className="lg:col-span-4 space-y-8">
            {/* Hour Card */}
            <div className="bg-brand-charcoal border border-brand-gold/10 rounded-2xl p-6 sm:p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2 rounded bg-brand-gold/10 border border-brand-gold/20 text-brand-gold">
                  <Clock size={18} />
                </div>
                <h3 className="font-serif text-lg font-bold text-brand-beige">{t('contact.hours') || 'Heures d\'Ouverture'}</h3>
              </div>

              <div className="space-y-3 font-sans">
                {openingHours.map((h) => (
                  <div
                    key={h.day}
                    className={`flex items-center justify-between text-xs sm:text-sm py-2.5 border-b border-brand-gold/5 last:border-b-0 ${
                      h.isClosed ? 'text-brand-beige/30' : 'text-brand-beige/85'
                    }`}
                  >
                    <span className="font-medium">{h.day}</span>
                    <div className="flex items-center gap-3">
                      <span>{h.time}</span>
                      <span
                        className={`text-[9px] font-mono uppercase tracking-wider px-2 py-0.5 rounded border ${
                          h.isClosed
                            ? 'bg-brand-red/10 border-brand-red/35 text-brand-red'
                            : h.status === 'Réduit' || h.status === 'Reduced'
                            ? 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                            : 'bg-brand-green/10 border-brand-green/20 text-brand-green'
                        }`}
                      >
                        {h.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Practical info Card */}
            <div className="bg-brand-charcoal border border-brand-gold/10 rounded-2xl p-6 sm:p-8 space-y-6">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded bg-brand-gold/10 border border-brand-gold/20 text-brand-gold">
                  <Star size={18} className="fill-brand-gold" />
                </div>
                <h3 className="font-serif text-lg font-bold text-brand-beige">
                  {language === 'fr' ? 'Renseignements' : 'Information & Inquiry'}
                </h3>
              </div>

              <div className="space-y-5 text-xs sm:text-sm font-sans divide-y divide-brand-gold/5">
                <div className="flex items-start gap-3.5 pt-0">
                  <MapPin size={18} className="text-brand-gold mt-1 shrink-0" />
                  <div>
                    <h4 className="font-bold text-brand-beige">{t('contact.address') || 'Adresse'}</h4>
                    <p className="text-brand-beige/65 mt-1 leading-relaxed">
                      1/6 Prachathipatai Road, Phra Nakhon, Bangkok, Thaïlande
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3.5 pt-4">
                  <Phone size={18} className="text-brand-gold mt-1 shrink-0" />
                  <div>
                    <h4 className="font-bold text-brand-beige">Téléphone direct</h4>
                    <a href="tel:+66958960395" className="text-brand-gold font-mono font-medium block mt-1 hover:underline">
                      +66 95 896 0395
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3.5 pt-4">
                  <Share2 size={18} className="text-brand-gold mt-1 shrink-0" />
                  <div>
                    <h4 className="font-bold text-brand-beige font-serif">Réseaux Sociaux</h4>
                    <div className="flex gap-3.5 mt-2">
                      <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-1.5 rounded bg-brand-gold/5 border border-brand-gold/10 text-brand-gold hover:bg-brand-gold hover:text-brand-dark transition-colors">
                        <Instagram size={14} />
                      </a>
                      <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="p-1.5 rounded bg-brand-gold/5 border border-brand-gold/10 text-brand-gold hover:bg-brand-gold hover:text-brand-dark transition-colors">
                        <Facebook size={14} />
                      </a>
                      <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" className="p-1.5 rounded bg-brand-gold/5 border border-brand-gold/10 text-brand-gold hover:bg-brand-gold hover:text-brand-dark transition-colors">
                        <Globe size={14} />
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Interactive map display (8 cols of 12) */}
          <div className="lg:col-span-8 flex flex-col justify-between">
            <div className="bg-brand-charcoal border border-brand-gold/10 rounded-2xl overflow-hidden h-full flex flex-col justify-between p-2">
              {/* Maps frame container */}
              <div className="relative w-full rounded-xl overflow-hidden aspect-[16/10] md:aspect-auto md:flex-1 min-h-[380px] bg-brand-dark border border-brand-gold/10">
                <iframe
                  title="Google Maps Location"
                  src={mapEmbedUrl}
                  width="100%"
                  height="100%"
                  style={{ border: 0, filter: 'grayscale(0.6) invert(0.9) contrast(1.2)' }} // Premium dark mode maps effect
                  allowFullScreen={true}
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Bottom detail panels */}
              <div className="p-4 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs font-sans">
                <div className="flex items-center gap-3 text-brand-beige/75 text-center sm:text-left">
                  <div className="w-2.5 h-2.5 rounded-full bg-brand-green shrink-0 animate-ping" />
                  <span>
                    {language === 'fr' 
                      ? "Emplacement d'exception idéalement placé près des temples phares de Bangkok." 
                      : "Exceptional location handpicked near key cultural landmarks and shrines."}
                  </span>
                </div>
                <a
                  href="https://maps.google.com/?q=The%20Family%201/6%20Prachathipatai%20Road,%20Phra%20Nakhon,%20Bangkok"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-4 py-2 bg-brand-gold/10 border border-brand-gold/25 text-brand-gold text-xs font-mono uppercase rounded-lg hover:bg-brand-gold hover:text-brand-dark whitespace-nowrap transition-colors cursor-pointer"
                >
                  {t('contact.btnDirection') || 'Itinéraire GPS'}
                </a>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
