import React, { useState } from 'react';
import { Play, Sparkles, Film, Heart, Eye } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function AtmosphereVideo() {
  const { language } = useLanguage();
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <section className="py-20 bg-brand-dark relative overflow-hidden border-t border-b border-brand-gold/10">
      {/* Decorative vector overlays */}
      <div className="absolute right-0 top-10 w-96 h-96 bg-[radial-gradient(circle_at_center,rgba(212,175,55,0.03),transparent_70%)] pointer-events-none" />
      <div className="absolute left-0 bottom-10 w-96 h-96 bg-[radial-gradient(circle_at_center,rgba(163,15,15,0.03),transparent_70%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
            {language === 'fr' ? 'Sensation Cinématique' : 'Cinematic Sensation'}
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold text-brand-beige mt-2 tracking-tight">
            {language === 'fr' ? 'La Cuisine en' : 'Live Kitchen in'} <span className="italic font-serif text-brand-gold">{language === 'fr' ? 'Mouvement' : 'Motion'}</span>
          </h2>
          <div className="w-12 h-0.5 bg-brand-gold mx-auto mt-4" />
          <p className="text-xs text-brand-beige/60 font-sans mt-4 max-w-md mx-auto leading-relaxed">
            {language === 'fr' 
              ? "Laissez-vous envoûter par le souffle du wok, la découpe des herbes fraîches et l'art ancestral du dressage thaïlandais."
              : "Immerse in the breath of the wok, the precise cutting of fresh wild herbs, and the ancestral art of Thai premium plating."}
          </p>
        </div>

        {/* Video Showcase Frame */}
        <div className="max-w-4xl mx-auto relative group rounded-3xl overflow-hidden border border-brand-gold/25 shadow-2xl bg-brand-charcoal aspect-video">
          
          <AnimatePresence mode="wait">
            {!isPlaying ? (
              <motion.div
                key="thumbnail"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.4 }}
                className="absolute inset-0 w-full h-full flex flex-col items-center justify-center cursor-pointer select-none"
                onClick={() => setIsPlaying(true)}
              >
                {/* Simulated cover image using a beautiful high-res cooking session */}
                <img
                  src="https://images.unsplash.com/photo-1556910103-1c02745aae4d?auto=format&fit=crop&q=80&w=1200"
                  alt="Kitchen atmosphere cookery"
                  className="absolute inset-0 w-full h-full object-cover brightness-40 group-hover:scale-102 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />

                {/* Cover subtle gradient overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-brand-dark/90 via-transparent to-brand-dark/30" />

                {/* Play Button & labels */}
                <div className="relative z-10 flex flex-col items-center gap-4 text-center px-4">
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-20 h-20 rounded-full bg-brand-gold text-brand-dark flex items-center justify-center shadow-2xl border-4 border-brand-charcoal cursor-pointer"
                  >
                    <Play size={28} className="fill-brand-dark ml-1 stroke-[2.5px]" />
                  </motion.div>
                  
                  <div>
                    <h3 className="font-serif text-lg sm:text-2xl font-bold text-white tracking-wide">
                      {language === 'fr' ? 'Le Feu & La Tradition du Chef' : 'The Holy Fire & Chef’s Tradition'}
                    </h3>
                    <p className="text-[10px] font-mono text-brand-gold uppercase tracking-widest mt-1.5 flex items-center justify-center gap-1.5">
                      <Film size={12} />
                      <span>{language === 'fr' ? 'Documentaire Culinaire • 2:15 Min' : 'Culinary Documentary • 2:15 Min'}</span>
                    </p>
                  </div>
                </div>

                {/* Subtle side indicators */}
                <div className="absolute bottom-4 right-4 text-[9px] font-mono tracking-widest text-[#F5E6C8]/45 uppercase flex items-center gap-1.5">
                  <Eye size={11} className="text-brand-gold" />
                  <span>{language === 'fr' ? '12.4K SPECTATEURS' : '12.4K WATCHING'}</span>
                </div>
              </motion.div>
            ) : (
              <motion.div
                key="player"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 w-full h-full"
              >
                {/* Traditional Youtube video showreel of Bangkok street food & cuisine */}
                <iframe
                  src="https://www.youtube.com/embed/S_g9qN8w3c8?autoplay=1&mute=0"
                  title="Wok street flavor culinary showreel"
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
                
                {/* Custom absolute button to exit video play mode */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setIsPlaying(false);
                  }}
                  className="absolute bottom-4 right-4 z-20 px-3 py-1.5 rounded-full bg-brand-dark/90 border border-brand-gold/30 text-[9px] font-mono text-brand-gold uppercase tracking-widest hover:bg-brand-gold hover:text-brand-dark transition-all cursor-pointer shadow-lg"
                >
                  {language === 'fr' ? 'Fermer la vidéo ✕' : 'Close Video ✕'}
                </button>
              </motion.div>
            )}
          </AnimatePresence>

        </div>

      </div>
    </section>
  );
}
