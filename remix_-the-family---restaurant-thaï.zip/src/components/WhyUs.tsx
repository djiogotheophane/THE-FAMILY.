import React from 'react';
import { Award, Carrot, Heart } from 'lucide-react';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function WhyUs() {
  const { t } = useLanguage();

  const features = [
    {
      icon: <Award className="w-6 h-6 text-brand-gold" />,
      title: t('why.item1.title'),
      description: t('why.item1.desc')
    },
    {
      icon: <Carrot className="w-6 h-6 text-brand-green" />,
      title: t('why.item2.title'),
      description: t('why.item2.desc')
    },
    {
      icon: <Heart className="w-6 h-6 text-brand-red" />,
      title: t('why.item3.title'),
      description: t('why.item3.desc')
    }
  ];

  return (
    <section id="why-us" className="py-24 bg-brand-charcoal border-y border-brand-gold/10 relative overflow-hidden">
      {/* Background patterns */}
      <div className="absolute right-0 top-0 w-96 h-96 bg-brand-gold/5 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute left-0 bottom-0 w-96 h-96 bg-brand-red/5 blur-[120px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
            {t('why.badge')}
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-beige mt-2 tracking-tight animate-fade-in">
            {t('why.title')}
          </h2>
          <div className="w-16 h-0.5 bg-brand-gold mx-auto mt-6" />
          <p className="text-sm sm:text-base text-brand-beige/70 mt-4 leading-relaxed">
            {t('why.desc')}
          </p>
        </div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {features.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -5, borderColor: 'rgba(212, 175, 55, 0.4)' }}
              className="bg-brand-dark/50 p-8 rounded-2xl border border-brand-gold/10 hover:shadow-2xl hover:shadow-brand-gold/5 transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-brand-gold/10 border border-brand-gold/20 flex items-center justify-center mb-6">
                  {item.icon}
                </div>
                <h3 className="font-serif text-lg font-bold text-brand-beige tracking-wide mb-3">
                  {item.title}
                </h3>
                <p className="text-sm text-brand-beige/70 leading-relaxed font-sans">
                  {item.description}
                </p>
              </div>
              <div className="mt-6 flex justify-end">
                <span className="w-6 h-px bg-brand-gold/20" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Premium highlight section with numbers */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 pt-12 border-t border-brand-gold/10 text-center">
          <div>
            <p className="font-serif text-4xl sm:text-5xl font-extrabold text-brand-gold">4.8</p>
            <p className="text-[11px] font-mono uppercase tracking-widest text-brand-beige/60 mt-2">
              {t('contact.ratingSub') || "Note Globale Voyageurs"}
            </p>
          </div>
          <div className="border-l border-brand-gold/10">
            <p className="font-serif text-4xl sm:text-5xl font-extrabold text-brand-gold">100%</p>
            <p className="text-[11px] font-mono uppercase tracking-widest text-brand-beige/60 mt-2">
              {t('why.statMaison') || "Fait Maison & Traditionnel"}
            </p>
          </div>
          <div className="border-l border-brand-gold/10">
            <p className="font-serif text-4xl sm:text-5xl font-extrabold text-brand-gold">30+</p>
            <p className="text-[11px] font-mono uppercase tracking-widest text-brand-beige/60 mt-2">
              {t('why.statRecettes') || "Recettes Ancestrales"}
            </p>
          </div>
          <div className="border-l border-brand-gold/10">
            <p className="font-serif text-4xl sm:text-5xl font-extrabold text-brand-gold">10k+</p>
            <p className="text-[11px] font-mono uppercase tracking-widest text-brand-beige/60 mt-2">
              {t('why.statClients') || "Clients Heureux"}
            </p>
          </div>
        </div>

      </div>
    </section>
  );
}
