import React, { useState, useMemo } from 'react';
import { Camera, Maximize2, X, ChevronLeft, ChevronRight, Compass } from 'lucide-react';
import { GALLERY_ITEMS } from '../data';
import { GalleryItem } from '../types';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function GallerySection() {
  const { t, language } = useLanguage();
  const [filter, setFilter] = useState<'all' | 'dish' | 'restaurant' | 'thailand'>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filterTabs = [
    { key: 'all', label: language === 'fr' ? 'Tous les mémoires' : 'All Memories' },
    { key: 'dish', label: language === 'fr' ? 'Nos Assiettes' : 'Our Plates' },
    { key: 'restaurant', label: language === 'fr' ? 'Le Lieu & L’Équipe' : 'The Place & Team' },
    { key: 'thailand', label: language === 'fr' ? 'Inspirations Thaïlande' : 'Thai Inspirations' }
  ];

  const itemTranslations: Record<string, Record<string, { title: string; desc: string }>> = {
    g1: {
      fr: { title: 'Pad Thai fumant au Wok', desc: 'Nouilles sautées à la minute avec notre tamarin fait maison.' },
      en: { title: 'Wok-Sizzled Pad Thai', desc: 'Stir-fried noodles prepared a la minute with our sweet signature tamarind pulp.' }
    },
    g2: {
      fr: { title: 'Curry Vert Traditionnel', desc: 'Crémeux, parfumé aux aubergines thaïes et basilic frais.' },
      en: { title: 'Traditional Green Curry', desc: 'Creamy and aromatic green curry infused with sweet Thai eggplants and fresh bird\'s eye basil.' }
    },
    g3: {
      fr: { title: 'Rouleaux de Printemps dorés', desc: 'Une enveloppe croustillante garnie d’herbes croquantes.' },
      en: { title: 'Crispy Golden Spring Rolls', desc: 'Crunchy wrapping loaded with fresh local herbs and tender vegetables.' }
    },
    g4: {
      fr: { title: 'Mango Sticky Rice Imperial', desc: 'Riz gluant onctueux à la coco et mangues jaunes sucrées.' },
      en: { title: 'Imperial Mango Sticky Rice', desc: 'Warm glutinous rice cooked in rich coconut milk flanked by ripe honey mangoes.' }
    },
    g5: {
      fr: { title: 'La Salle Principale', desc: 'Un espace intime mariant noblesse du teck et éclairage tamisé.' },
      en: { title: 'The Teak Dining Hall', desc: 'An intimate sanctuary combining royal teak wood elements with soft golden lighting.' }
    },
    g6: {
      fr: { title: 'Notre Équipe Cuisine', desc: 'Une famille de chefs unis pour préserver les recettes d’antan.' },
      en: { title: 'Our Family Kitchen Team', desc: 'A dedicated line of home-cook masters united to perpetuate centuries-old recipes.' }
    },
    g7: {
      fr: { title: 'Le Cœur Historique de Phra Nakhon', desc: 'Situé à deux pas des plus majestueux temples de Bangkok.' },
      en: { title: 'Phra Nakhon Historic Sanctuary', desc: 'Nestled just footsteps away from the most iconic, majestic shrines of Bangkok.' }
    },
    g8: {
      fr: { title: 'Bangkok Lumineux de Nuit', desc: 'L’animation féérique de la cité des anges après le coucher du soleil.' },
      en: { title: 'Bangkok Night Skylines', desc: 'The magnificent neon and river light shows of the city of angels after twilight.' }
    },
    g9: {
      fr: { title: 'Marché aux Épices Local', desc: 'Où nous sélectionnons personnellement chaque matin nos piments et galanga.' },
      en: { title: 'Local Fresh Spice Market', desc: 'Where our family hand-selects organic herbs, lime leaves, and galangal every dawn.' }
    },
  };

  const getTranslatedItem = (item: GalleryItem) => {
    const lang = language === 'fr' ? 'fr' : 'en';
    const dict = itemTranslations[item.id];
    if (dict && dict[lang]) {
      return {
        ...item,
        title: dict[lang].title,
        description: dict[lang].desc
      };
    }
    return item;
  };

  const filteredItems = useMemo(() => {
    const baseList = filter === 'all' ? GALLERY_ITEMS : GALLERY_ITEMS.filter((item) => item.category === filter);
    return baseList.map(item => getTranslatedItem(item));
  }, [filter, language]);

  const handleOpenLightbox = (item: GalleryItem) => {
    // Find absolute index of item in currently filtered array to allow navigation
    const idx = filteredItems.findIndex(i => i.id === item.id);
    if (idx !== -1) setLightboxIndex(idx);
  };

  const handleNavPrev = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((prev) => (prev !== null && prev > 0 ? prev - 1 : filteredItems.length - 1));
  };

  const handleNavNext = () => {
    if (lightboxIndex === null) return;
    setLightboxIndex((prev) => (prev !== null && prev < filteredItems.length - 1 ? prev + 1 : 0));
  };

  return (
    <section id="gallery" className="py-24 bg-brand-charcoal relative border-y border-brand-gold/15 overflow-hidden">
      <div className="absolute right-0 bottom-0 w-80 h-80 bg-brand-red/5 blur-[90px] rounded-full pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
            – {language === 'fr' ? 'Immersion Visuelle' : 'Visual Immersion'}
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-beige mt-2 tracking-tight">
            {language === 'fr' ? 'Souvenirs de' : 'Glimpses of'} <span className="italic font-serif text-brand-gold">The Family</span>
          </h2>
          <div className="w-12 h-0.5 bg-brand-gold mx-auto mt-6" />
          <p className="text-xs sm:text-sm text-brand-beige/65 mt-4 leading-relaxed font-sans">
            {language === 'fr' 
              ? "Laissez-vous captiver par l'esthétique de nos plats, le raffinement boisé de notre salle et les merveilles authentiques de notre beau pays."
              : "Let yourself be captivated by our dishes' aesthetic, the teak-wood geometry of our hall, and the authentic wonders of Thailand."}
          </p>
        </div>

        {/* Filters bar */}
        <div className="flex justify-center flex-wrap gap-2 mb-12">
          {filterTabs.map((tab) => (
            <button
              key={tab.key}
              onClick={() => {
                setFilter(tab.key as any);
                setLightboxIndex(null); // Clear active index when changing tabs
              }}
              className={`px-5 py-2.5 rounded-xl border text-xs font-mono uppercase tracking-widest transition-all cursor-pointer ${
                filter === tab.key
                  ? 'bg-brand-gold text-brand-dark border-brand-gold font-bold shadow-lg shadow-brand-gold/15'
                  : 'bg-brand-dark/40 text-brand-beige/70 border-brand-gold/10 hover:border-brand-gold/30 hover:text-brand-gold'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Gallery Grid */}
        <motion.div 
          layout
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          <AnimatePresence mode="popLayout">
            {filteredItems.map((item) => (
              <motion.div
                layout
                key={item.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                className="group relative h-72 rounded-2xl overflow-hidden border border-brand-gold/10 hover:border-brand-gold/45 cursor-pointer shadow-lg hover:shadow-2xl transition-all duration-500 bg-brand-dark"
                onClick={() => handleOpenLightbox(item)}
              >
                {/* Visual */}
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />

                {/* Dark Vignette Overlay on Hover */}
                <div className="absolute inset-0 bg-gradient-to-t from-brand-dark via-brand-dark/30 to-transparent opacity-60 group-hover:opacity-90 transition-opacity duration-300" />

                {/* Expand Hover Badge in Middle */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-12 h-12 rounded-full bg-brand-gold text-brand-dark flex items-center justify-center shadow-xl">
                    <Maximize2 size={18} />
                  </div>
                </div>

                {/* Bottom Title Text panel overlay */}
                <div className="absolute bottom-6 left-6 right-6 transition-transform duration-300 translate-y-2 group-hover:translate-y-0">
                  <span className="text-[9px] font-mono uppercase tracking-[0.2em] text-brand-gold bg-brand-gold/10 border border-brand-gold/30 px-2.5 py-1 rounded-full">
                    {item.category === 'dish' 
                      ? (language === 'fr' ? 'Spécialités' : 'Specialties') 
                      : item.category === 'restaurant' 
                        ? (language === 'fr' ? 'Notre Lieu' : 'Our Haven') 
                        : (language === 'fr' ? 'Thaïlande' : 'Thailand')}
                  </span>
                  <h3 className="font-serif text-lg font-bold text-white mt-3 leading-tight text-shadow">
                    {item.title}
                  </h3>
                  <p className="text-xs text-brand-beige/50 font-sans mt-1 line-clamp-1 group-hover:block transition-all">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>

        {/* Fullscreen Lightbox Overlay */}
        <AnimatePresence>
          {lightboxIndex !== null && (
            <div className="fixed inset-0 z-50 bg-brand-dark/95 backdrop-blur-md flex items-center justify-center p-4">
              {/* Close backdrop hit zone */}
              <div className="absolute inset-0" onClick={() => setLightboxIndex(null)} />

              {/* Lightbox content shell */}
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="relative max-w-4xl w-full flex flex-col items-center z-10 animate-duration-300"
              >
                {/* Header Close triggers */}
                <div className="absolute -top-12 right-0 left-0 flex items-center justify-between text-brand-beige text-xs font-mono">
                  <span>{language === 'fr' ? 'CLICHÉ' : 'PHOTO'} {lightboxIndex + 1} / {filteredItems.length}</span>
                  <button
                    onClick={() => setLightboxIndex(null)}
                    className="flex items-center gap-1.5 text-brand-gold hover:text-white transition-colors bg-brand-gold/10 px-3 py-1.5 rounded-full border border-brand-gold/20 cursor-pointer"
                  >
                    <X size={15} />
                    {language === 'fr' ? 'Fermer' : 'Close'}
                  </button>
                </div>

                {/* Large Preview Panel */}
                <div className="relative w-full aspect-[4/3] md:aspect-[16/10] max-h-[70vh] rounded-2xl overflow-hidden border border-brand-gold/30 shadow-2xl bg-brand-charcoal flex items-center justify-center">
                  <img
                    src={filteredItems[lightboxIndex].imageUrl}
                    alt={filteredItems[lightboxIndex].title}
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />

                  {/* Navigation paddles */}
                  <button
                    onClick={handleNavPrev}
                    className="absolute left-4 top-1/2 -translate-y-1/2 w-10 md:w-12 h-10 md:h-12 rounded-full bg-brand-dark/80 hover:bg-brand-gold text-brand-gold hover:text-brand-dark border border-brand-gold/30 flex items-center justify-center transition-all cursor-pointer shadow-lg z-20"
                    aria-label="Cliché précédent"
                  >
                    <ChevronLeft size={22} />
                  </button>
                  <button
                    onClick={handleNavNext}
                    className="absolute right-4 top-1/2 -translate-y-1/2 w-10 md:w-12 h-10 md:h-12 rounded-full bg-brand-dark/80 hover:bg-brand-gold text-brand-gold hover:text-brand-dark border border-brand-gold/30 flex items-center justify-center transition-all cursor-pointer shadow-lg z-20"
                    aria-label="Cliché suivant"
                  >
                    <ChevronRight size={22} />
                  </button>
                </div>

                {/* Legend panel below image */}
                <div className="w-full bg-brand-charcoal border border-brand-gold/20 p-6 rounded-b-2xl -mt-2 text-center">
                  <span className="text-[10px] uppercase tracking-widest text-[#D4AF37] font-mono">
                    {filteredItems[lightboxIndex].category.toUpperCase()} – {language === 'fr' ? 'COORDONNÉE BANGKOK' : 'BANGKOK COORDINATE'}
                  </span>
                  <h3 className="font-serif text-xl font-bold text-white mt-1.5">
                    {filteredItems[lightboxIndex].title}
                  </h3>
                  <p className="text-xs sm:text-sm text-brand-beige/75 mt-2 max-w-xl mx-auto font-sans">
                    {filteredItems[lightboxIndex].description}
                  </p>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
