import React, { useState, useMemo } from 'react';
import { Search, Filter, Flame, ShoppingCart, Check, Heart, Sparkles, X, ToggleLeft, ArrowUpDown, Eye, Leaf, ShieldAlert } from 'lucide-react';
import { MenuItem } from '../types';
import { MENU_ITEMS } from '../data';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface MenuSectionProps {
  onAddToCart: (item: MenuItem, selectedOption?: string) => void;
  onViewDish?: (item: MenuItem) => void;
}

export default function MenuSection({ onAddToCart, onViewDish }: MenuSectionProps) {
  const { t, language } = useLanguage();

  // Tabs config
  const categories = [
    { key: 'starters', label: t('menu.cat.starters') },
    { key: 'mains', label: t('menu.cat.mains') },
    { key: 'vegetarian', label: t('menu.cat.vegetarian') },
    { key: 'desserts', label: t('menu.cat.desserts') },
    { key: 'drinks', label: t('menu.cat.drinks') }
  ];

  const [activeTab, setActiveTab] = useState<string>('mains');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Dietary filters state
  const [selectedTag, setSelectedTag] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'default' | 'priceAsc' | 'priceDesc'>('default');

  // Customization selection state
  const [customizingItem, setCustomizingItem] = useState<MenuItem | null>(null);
  const [chosenOption, setChosenOption] = useState<string>('Poulet fermier');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const proteinOptions = [
    { label: language === 'fr' ? 'Poulet fermier' : 'Farmhouse Chicken', priceMod: 0 },
    { label: language === 'fr' ? 'Crevettes tigrées géantes' : 'Giant Tiger Prawns', priceMod: 60 },
    { label: language === 'fr' ? 'Bœuf de Chiang Mai' : 'Chiang Mai Beef', priceMod: 40 },
    { label: language === 'fr' ? 'Tofu biologique croustillant' : 'Crispy Organic Tofu', priceMod: -20 },
  ];

  // Filtering + Sorting Logics
  const filteredAndSortedItems = useMemo(() => {
    let list = MENU_ITEMS.filter((item) => {
      // Step 1: Category Check
      if (item.category !== activeTab) return false;

      // Step 2: Search Query check (handles french name, english name or description)
      const query = searchQuery.toLowerCase().trim();
      if (query) {
        const matchesName = item.name.toLowerCase().includes(query);
        const matchesEnglish = item.englishName?.toLowerCase().includes(query) ?? false;
        const matchesDesc = item.description.toLowerCase().includes(query);
        if (!matchesName && !matchesEnglish && !matchesDesc) return false;
      }

      // Step 3: Tag filters
      if (selectedTag !== 'all') {
        if (selectedTag === 'spicy' && item.spicyLevel === 0) return false;
        if (selectedTag === 'vegetarian' && !item.tags.includes('vegetarian')) return false;
        if (selectedTag === 'vegan' && !item.tags.includes('vegan')) return false;
        if (selectedTag === 'gluten-free' && !item.tags.includes('gluten-free')) return false;
        if (selectedTag === 'signature' && !item.tags.includes('signature')) return false;
      }

      return true;
    });

    // Step 4: Sorting
    if (sortBy === 'priceAsc') {
      list = [...list].sort((a, b) => a.price - b.price);
    } else if (sortBy === 'priceDesc') {
      list = [...list].sort((a, b) => b.price - a.price);
    }

    return list;
  }, [activeTab, searchQuery, selectedTag, sortBy]);

  const handleOrderInitiation = (item: MenuItem) => {
    // If it is a Main, or Som Tom, or special soups, trigger choice
    if (item.category === 'mains' || item.id === 's2' || item.id === 'v1' || item.id === 'v3') {
      setChosenOption(language === 'fr' ? 'Poulet fermier' : 'Farmhouse Chicken');
      setCustomizingItem(item);
    } else {
      onAddToCart(item);
      triggerToast(language === 'fr' ? item.name : (item.englishName || item.name));
    }
  };

  const handleApplyCustomOptions = () => {
    if (!customizingItem) return;
    onAddToCart(customizingItem, chosenOption);
    const displayName = language === 'fr' ? customizingItem.name : (customizingItem.englishName || customizingItem.name);
    triggerToast(`${displayName} [${chosenOption}]`);
    setCustomizingItem(null);
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  return (
    <section id="menu" className="py-24 bg-brand-dark relative overflow-hidden">
      <div className="absolute right-0 top-1/3 w-80 h-80 bg-brand-gold/5 blur-[100px] pointer-events-none rounded-full" />
      <div className="absolute left-0 bottom-1/3 w-80 h-80 bg-brand-red/5 blur-[100px] pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-xs font-mono uppercase tracking-[0.3em] text-brand-gold">
            {t('menu.badge')}
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold text-brand-beige mt-2 tracking-tight">
            {t('menu.title').split(' ').slice(0, -1).join(' ')} <span className="italic font-serif text-brand-gold">{t('menu.title').split(' ').slice(-1)}</span>
          </h2>
          <div className="w-12 h-0.5 bg-brand-gold mx-auto mt-6" />
        </div>

        {/* Search, Tag Filtering, Sorting Controls row */}
        <div className="bg-brand-charcoal/80 rounded-2xl border border-brand-gold/15 p-6 mb-10 shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            
            {/* Search Input (5 cols) */}
            <div className="lg:col-span-5 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-gold/50 w-4.5 h-4.5" />
              <input
                type="text"
                placeholder={t('menu.searchPlaceholder')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-brand-dark/90 border border-brand-gold/25 rounded-xl pl-12 pr-4 py-3 text-xs sm:text-sm text-brand-beige placeholder-brand-beige/35 focus:outline-none focus:border-brand-gold/60 focus:ring-1 focus:ring-brand-gold/40 transition-all font-sans"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-beige/40 hover:text-brand-gold"
                >
                  <X size={15} />
                </button>
              )}
            </div>

            {/* Tag Filter selection (5 cols) */}
            <div className="lg:col-span-4 flex flex-wrap gap-2">
              {[
                { key: 'all', label: language === 'fr' ? '🌐 Tout' : '🌐 All' },
                { key: 'signature', label: language === 'fr' ? '🏆 Signatures' : '🏆 Chef Specials' },
                { key: 'spicy', label: language === 'fr' ? '🔥 Épicé' : '🔥 Spicy' },
                { key: 'vegetarian', label: language === 'fr' ? '🌱 Végétarien' : '🌱 Vegetarian' },
                { key: 'gluten-free', label: language === 'fr' ? '🌾 Sans Gluten' : '🌾 Gluten-Free' }
              ].map((tag) => (
                <button
                  key={tag.key}
                  onClick={() => setSelectedTag(tag.key)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono uppercase tracking-wider border transition-all cursor-pointer ${
                    selectedTag === tag.key
                      ? 'bg-brand-gold text-brand-dark border-brand-gold font-bold shadow-lg'
                      : 'bg-brand-dark/40 text-brand-beige/75 border-brand-gold/10 hover:border-brand-gold/30 hover:text-brand-gold'
                  }`}
                >
                  {tag.label}
                </button>
              ))}
            </div>

            {/* Sorting trigger (3 cols) */}
            <div className="lg:col-span-3">
              <div className="flex items-center gap-2 bg-brand-dark/50 border border-brand-gold/15 rounded-xl px-3 py-2">
                <ArrowUpDown size={14} className="text-brand-gold/60" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="w-full bg-transparent text-xs text-brand-beige/85 focus:outline-none cursor-pointer font-sans"
                >
                  <option value="default" className="bg-brand-charcoal text-brand-beige">{language === 'fr' ? 'Tri par défaut' : 'Default Sorting'}</option>
                  <option value="priceAsc" className="bg-brand-charcoal text-brand-beige">{language === 'fr' ? 'Prix : croissant' : 'Price: Low to High'}</option>
                  <option value="priceDesc" className="bg-brand-charcoal text-[#F5E6C8]">{language === 'fr' ? 'Prix : décroissant' : 'Price: High to Low'}</option>
                </select>
              </div>
            </div>

          </div>
        </div>

        {/* Categories Tab navigation row */}
        <div className="flex justify-start md:justify-center overflow-x-auto pb-4 mb-12 scrollbar-none gap-2 border-b border-brand-gold/10">
          {categories.map((cat) => (
            <button
              key={cat.key}
              onClick={() => {
                setActiveTab(cat.key);
                setSelectedTag('all'); // Clear specific cross tag when shifting main categories safely
              }}
              className={`px-6 py-3 text-xs sm:text-sm font-serif font-bold uppercase tracking-widest whitespace-nowrap border-t-2 transition-all duration-300 relative cursor-pointer ${
                activeTab === cat.key
                  ? 'border-brand-gold text-brand-gold bg-brand-gold/5'
                  : 'border-transparent text-brand-beige/65 hover:text-brand-gold hover:bg-brand-gold/5'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Dynamic Display Grid */}
        <AnimatePresence mode="wait">
          {filteredAndSortedItems.length > 0 ? (
            <motion.div
              key={`${activeTab}-${searchQuery}-${selectedTag}-${sortBy}`}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            >
              {filteredAndSortedItems.map((item) => {
                const itemDisplayName = language === 'fr' ? item.name : (item.englishName || item.name);
                const secondaryName = language === 'fr' ? item.englishName : item.name;

                return (
                  <div
                    key={item.id}
                    className="bg-brand-charcoal/45 group rounded-2xl border border-brand-gold/10 overflow-hidden hover:border-brand-gold/25 transition-all duration-300 flex flex-col justify-between"
                  >
                    <div className="p-5 flex gap-4">
                      {/* Small visual display left with interactive hover overlays */}
                      <div 
                        onClick={() => onViewDish?.(item)}
                        className="w-24 h-24 rounded-xl overflow-hidden shrink-0 relative bg-brand-dark cursor-pointer group/image"
                        title={language === 'fr' ? 'Détails du plat' : 'View ingredients & specs'}
                      >
                        <img
                          src={item.image}
                          alt={itemDisplayName}
                          className="w-full h-full object-cover transition-transform group-hover:scale-105"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute inset-0 bg-brand-dark/50 opacity-0 group-hover/image:opacity-100 flex items-center justify-center transition-opacity">
                          <Eye size={16} className="text-brand-gold" />
                        </div>
                      </div>

                      {/* Meta info right */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-1.5">
                          <h3 
                            onClick={() => onViewDish?.(item)}
                            className="font-serif text-sm sm:text-base font-bold text-brand-beige leading-tight line-clamp-2 cursor-pointer hover:text-brand-gold transition-colors"
                          >
                            {itemDisplayName}
                          </h3>
                        </div>
                        
                        {secondaryName && (
                          <p className="text-[9px] font-mono uppercase tracking-widest text-brand-gold/50 mt-1">
                            {secondaryName}
                          </p>
                        )}

                        <p className="text-xs text-[#F5E6C8]/65 leading-relaxed line-clamp-3 mt-2 font-sans">
                          {item.description}
                        </p>
                      </div>
                    </div>

                    {/* Pricing action bottom footer bar */}
                    <div className="border-t border-brand-gold/10 px-5 py-3 flex items-center justify-between bg-brand-dark/30 rounded-b-2xl">
                      <div className="flex flex-col">
                        <span className="font-serif text-brand-gold font-extrabold text-sm sm:text-base">
                          {item.price} ฿
                        </span>
                        <span className="text-[9px] font-mono text-brand-beige/35">
                          ~{(item.price / 36).toFixed(1)} €
                        </span>
                      </div>

                      {/* High-quality responsive visual badges */}
                      <div className="flex flex-wrap gap-1 items-center justify-end max-w-[140px]">
                        {item.spicyLevel > 0 && (
                          <span 
                            className="flex items-center gap-0.5 bg-brand-red/10 border border-brand-red/30 px-1.5 py-0.5 rounded-[4px] text-[7px] text-brand-red font-mono font-bold uppercase shrink-0"
                            title={`Spice level: ${item.spicyLevel}`}
                          >
                            <Flame size={8} className="fill-brand-red" />
                            <span>LVL {item.spicyLevel}</span>
                          </span>
                        )}
                        
                        {item.tags.includes('signature') && (
                          <span className="flex items-center gap-0.5 bg-brand-gold/15 text-brand-gold border border-brand-gold/25 text-[7px] font-mono font-black px-1.5 py-0.5 rounded-[4px] shrink-0">
                            <Sparkles size={8} />
                            <span>EXC</span>
                          </span>
                        )}

                        {item.tags.includes('vegetarian') && (
                          <span className="flex items-center gap-0.5 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 text-[7px] font-mono font-bold px-1.5 py-0.5 rounded-[4px] shrink-0">
                            <Leaf size={8} />
                            <span>VEG</span>
                          </span>
                        )}

                        {item.tags.includes('gluten-free') && (
                          <span className="bg-amber-500/10 text-amber-500 border border-amber-500/20 text-[7px] font-mono font-bold px-1.5 py-0.5 rounded-[4px] shrink-0" title="Gluten Protected">
                            GF
                          </span>
                        )}
                      </div>

                      <button
                        onClick={() => handleOrderInitiation(item)}
                        className="p-1.5 sm:p-2 rounded-lg bg-brand-gold/10 border border-brand-gold/20 text-brand-gold hover:bg-brand-gold hover:text-brand-dark transition-all duration-300 cursor-pointer text-[10px] font-mono uppercase flex items-center gap-1 shrink-0"
                      >
                        <ShoppingCart size={11} />
                        <span className="hidden sm:inline">{t('menu.addCart')}</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </motion.div>
          ) : (
            <div className="text-center py-20 bg-brand-charcoal/20 rounded-2xl border border-brand-gold/5 max-w-lg mx-auto">
              <p className="text-brand-beige/50 font-serif text-lg italic">{t('menu.empty')}</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedTag('all');
                }}
                className="mt-4 px-4 py-2 border border-brand-gold/30 rounded text-brand-gold text-xs font-mono uppercase tracking-widest hover:bg-brand-gold/10 cursor-pointer"
              >
                {language === 'fr' ? 'Réinitialiser les filtres' : 'Reset filters'}
              </button>
            </div>
          )}
        </AnimatePresence>

        {/* Dynamic Add notification */}
        <AnimatePresence>
          {toastMessage && (
            <motion.div
              initial={{ opacity: 0, y: 50, x: '-50%' }}
              animate={{ opacity: 1, y: 0, x: '-50%' }}
              exit={{ opacity: 0, y: 20, x: '-50%' }}
              className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 flex items-center gap-2 bg-brand-green border border-emerald-500 text-white px-5 py-3 rounded-full shadow-2xl font-sans text-xs font-medium"
            >
              <Check size={14} className="bg-white/10 p-0.5 rounded-full" />
              <span>{t('specialties.addedSuccess')} : <strong>{toastMessage}</strong></span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Protein Customization Overlay Dialog */}
        <AnimatePresence>
          {customizingItem && (
            <div className="fixed inset-0 bg-brand-dark/90 backdrop-blur-sm flex items-center justify-center z-50 p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-brand-charcoal rounded-2xl border border-brand-gold/30 p-6 sm:p-8 max-w-md w-full relative"
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="text-[10px] font-mono text-brand-gold uppercase tracking-widest">
                      {t('menu.customization') || "Customisation"}
                    </span>
                    <h3 className="font-serif text-lg sm:text-xl font-bold text-brand-beige mt-0.5 animate-fade-in text-wrap">
                      {language === 'fr' ? customizingItem.name : (customizingItem.englishName || customizingItem.name)}
                    </h3>
                  </div>
                  <button
                    onClick={() => setCustomizingItem(null)}
                    className="p-1 rounded text-brand-gold hover:bg-brand-gold/15 cursor-pointer"
                  >
                    <X size={18} />
                  </button>
                </div>

                <p className="text-xs text-[#F5E6C8]/65 mb-6 font-sans">
                  {language === 'fr' ? 'Associez la protéine parfaite avec ce plat délicat pour magnifier les arômes.' : 'Select the perfect protein to pair with this exquisite dish.'}
                </p>

                {/* Protein check list */}
                <div className="space-y-2.5 mb-8">
                  {proteinOptions.map((opt) => (
                    <button
                      key={opt.label}
                      onClick={() => setChosenOption(opt.label)}
                      className={`w-full flex items-center justify-between p-3.5 rounded-xl border text-xs font-sans transition-all text-left cursor-pointer ${
                        chosenOption === opt.label
                          ? 'border-brand-gold bg-brand-gold/10 text-brand-gold font-bold'
                          : 'border-brand-gold/10 bg-brand-dark/45 text-brand-beige/85 hover:bg-brand-gold/5'
                      }`}
                    >
                      <span className="flex items-center gap-2">
                        {chosenOption === opt.label && <span className="w-1.5 h-1.5 rounded-full bg-brand-gold" />}
                        {opt.label}
                      </span>
                      <span className="font-mono text-brand-gold">
                        {opt.priceMod === 0 
                          ? (language === 'fr' ? 'Inclus' : 'Included') 
                          : opt.priceMod > 0 
                            ? `+${opt.priceMod} ฿` 
                            : `${opt.priceMod} ฿`
                        }
                      </span>
                    </button>
                  ))}
                </div>

                {/* Action triggers */}
                <div className="flex gap-4">
                  <button
                    onClick={() => setCustomizingItem(null)}
                    className="w-1/2 py-3 rounded-lg border border-brand-gold/25 font-mono text-xs uppercase text-brand-beige/70 hover:bg-brand-gold/5 cursor-pointer"
                  >
                    {language === 'fr' ? 'Fermer' : 'Close'}
                  </button>
                  <button
                    onClick={handleApplyCustomOptions}
                    className="w-1/2 py-3 rounded-lg bg-brand-gold text-brand-dark font-extrabold font-mono text-xs uppercase tracking-wider cursor-pointer"
                  >
                    {language === 'fr' ? 'Confirmer' : 'Confirm'}
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
