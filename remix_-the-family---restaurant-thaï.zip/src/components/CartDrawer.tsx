import React, { useState } from 'react';
import { ShoppingBag, X, Trash2, Plus, Minus, CreditCard, ShieldCheck, MapPin, Truck, Utensils, CheckCircle, RefreshCw, AlertCircle } from 'lucide-react';
import { CartItem } from '../types';
import { motion } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onUpdateQuantity: (id: string, amount: number) => void;
  onRemoveItem: (id: string) => void;
  onUpdateNotes: (id: string, notes: string) => void;
  onClearCart: () => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onUpdateNotes,
  onClearCart
}: CartDrawerProps) {
  const { t, language } = useLanguage();
  const [deliveryMode, setDeliveryMode] = useState<'delivery' | 'pickup'>('delivery');
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'form' | 'tracking'>('cart');

  // Checkout inputs
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');
  const [deliveryAddress, setDeliveryAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'credit' | 'promptpay' | 'cash'>('credit');
  
  // Simulated Card Details
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');

  // Tracking details
  const [currentOrderNumber, setCurrentOrderNumber] = useState('');
  const [trackingStep, setTrackingStep] = useState<1 | 2 | 3 | 4>(1);

  if (!isOpen) return null;

  // Calculs financiers
  const calculateSubtotal = () => {
    return cartItems.reduce((acc, current) => {
      // Calculate active base item price
      let basePrice = current.menuItem.price;
      // Adjust if special protein option addition
      if (current.selectedOption) {
        if (current.selectedOption.includes('Crevettes') || current.selectedOption.includes('Shrimp')) basePrice += 60;
        if (current.selectedOption.includes('Bœuf') || current.selectedOption.includes('Beef')) basePrice += 40;
        if (current.selectedOption.includes('Tofu') || current.selectedOption.includes('Tofu')) basePrice -= 20;
      }
      return acc + (basePrice * current.quantity);
    }, 0);
  };

  const subtotal = calculateSubtotal();
  const taxRate = 0.07; // 7% VAT
  const vat = Math.round(subtotal * taxRate);
  const deliveryFee = deliveryMode === 'delivery' ? 50 : 0;
  const total = subtotal + vat + deliveryFee;

  const handleStartCheckout = () => {
    if (cartItems.length === 0) return;
    setCheckoutStep('form');
  };

  const handleConfirmOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName || !customerPhone || (deliveryMode === 'delivery' && !deliveryAddress)) return;

    // Generate simulated order receipt
    const codeGen = `TF-${Math.floor(100000 + Math.random() * 900000)}`;
    setCurrentOrderNumber(codeGen);
    setCheckoutStep('tracking');
    setTrackingStep(1);

    // Simulate cooking steps
    const timer1 = setTimeout(() => setTrackingStep(2), 6000); // Cooking
    const timer2 = setTimeout(() => setTrackingStep(3), 14000); // Ready for pickup/rider
    const timer3 = setTimeout(() => setTrackingStep(4), 22000); // Dispatched
    
    // Save order data to local history just in case
    const orderLog = {
      orderNumber: codeGen,
      name: customerName,
      items: cartItems.map(i => ({ name: i.menuItem.name, q: i.quantity, opt: i.selectedOption })),
      total: total,
      time: new Date().toLocaleTimeString(),
      mode: deliveryMode,
    };
    localStorage.setItem('the_family_latest_order', JSON.stringify(orderLog));
  };

  const handleResetCheckoutAndClear = () => {
    onClearCart();
    setCheckoutStep('cart');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-brand-dark/80 backdrop-blur-sm flex justify-end">
      {/* Click outside backdrop close zone */}
      <div className="absolute inset-0" onClick={onClose} />

      {/* Slideout Container */}
      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="relative w-full max-w-lg bg-brand-charcoal h-full flex flex-col justify-between py-6 shadow-2xl border-l border-brand-gold/15 z-10"
      >
        {/* Header toolbar */}
        <div className="flex justify-between items-center px-6 pb-4 border-b border-brand-gold/10">
          <div>
            <div className="flex items-center gap-2">
              <ShoppingBag className="text-brand-gold w-4.5 h-4.5" />
              <h2 className="font-serif text-lg font-bold text-brand-beige">
                {language === 'fr' ? 'Commande en Ligne' : 'Online Order'}
              </h2>
            </div>
            <p className="text-[10px] font-mono tracking-wider uppercase text-brand-beige/50 mt-1">
              THE FAMILY – BANGKOK SERVICE
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full bg-brand-gold/10 hover:bg-brand-gold/20 text-brand-gold border border-brand-gold/10 cursor-pointer"
          >
            <X size={16} />
          </button>
        </div>

        {/* Dynamic Inner shell based on checkoutStep */}
        {checkoutStep === 'cart' && (
          <>
            {/* 1. SHOPPING CART LISTING */}
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
              
              {/* Delivery Option triggers */}
              <div className="grid grid-cols-2 gap-3 bg-brand-dark/60 p-1.5 rounded-xl border border-brand-gold/10 select-none">
                <button
                  onClick={() => setDeliveryMode('delivery')}
                  className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-mono uppercase transition-all cursor-pointer ${
                    deliveryMode === 'delivery'
                      ? 'bg-brand-gold text-brand-dark font-black'
                      : 'text-brand-beige/60 hover:text-brand-beige'
                  }`}
                >
                  <Truck size={14} />
                  {language === 'fr' ? 'Livraison (50 ฿)' : 'Delivery (50 ฿)'}
                </button>
                <button
                  onClick={() => setDeliveryMode('pickup')}
                  className={`flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-mono uppercase transition-all cursor-pointer ${
                    deliveryMode === 'pickup'
                      ? 'bg-brand-gold text-brand-dark font-black'
                      : 'text-brand-beige/60 hover:text-brand-beige'
                  }`}
                >
                  <Utensils size={14} />
                  {language === 'fr' ? 'À Emporter (Gratuit)' : 'Take-Away (Free)'}
                </button>
              </div>

              {cartItems.length > 0 ? (
                <div className="space-y-4 pt-2">
                  {cartItems.map((item) => {
                    const basePrice = item.menuItem.price;
                    let pricePlus = 0;
                    if (item.selectedOption) {
                      if (item.selectedOption.includes('Crevettes') || item.selectedOption.includes('Shrimp')) pricePlus += 60;
                      if (item.selectedOption.includes('Bœuf') || item.selectedOption.includes('Beef')) pricePlus += 40;
                      if (item.selectedOption.includes('Tofu')) pricePlus -= 20;
                    }
                    const singleItemPrice = basePrice + pricePlus;

                    return (
                      <div
                        key={item.id}
                        className="bg-brand-dark/45 rounded-xl border border-brand-gold/5 p-4 flex gap-4 hover:border-brand-gold/15 transition-all relative"
                      >
                        {/* Thumbnail */}
                        <div className="w-16 h-16 rounded-lg overflow-hidden shrink-0 bg-brand-charcoal">
                          <img
                            src={item.menuItem.image}
                            alt={language === 'fr' ? item.menuItem.name : (item.menuItem.englishName || item.menuItem.name)}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Text and Actions */}
                        <div className="flex-1 min-w-0 flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between items-start">
                              <h3 className="font-serif font-bold text-sm text-brand-beige leading-tight pr-6 truncate">
                                {language === 'fr' ? item.menuItem.name : (item.menuItem.englishName || item.menuItem.name)}
                              </h3>
                              <button
                                onClick={() => onRemoveItem(item.id)}
                                className="absolute top-4 right-4 text-brand-beige/30 hover:text-brand-red transition-colors cursor-pointer"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>

                            {/* Option tag specifier */}
                            {item.selectedOption && (
                              <span className="inline-block mt-1 text-[9px] font-mono uppercase bg-brand-gold/10 text-brand-gold px-1.5 py-0.5 rounded border border-brand-gold/20">
                                {language === 'fr' ? 'Protéine' : 'Protein'} : {item.selectedOption}
                              </span>
                            )}
                          </div>

                          {/* Notes field */}
                          <div className="mt-1.5 font-sans">
                            <input
                              type="text"
                              value={item.notes || ''}
                              onChange={(e) => onUpdateNotes(item.id, e.target.value)}
                              placeholder={language === 'fr' ? "Notes: ex. Sans ciboulette, pimenté..." : "Notes: e.g. No onions, extra spicy..."}
                              className="w-full bg-transparent text-[10px] text-brand-beige/40 focus:text-brand-beige focus:outline-none border-b border-brand-gold/10 focus:border-brand-gold/30 pb-0.5"
                            />
                          </div>

                          {/* Controls & Price bottom */}
                          <div className="flex items-center justify-between mt-3">
                            <div className="flex items-center gap-2.5 bg-brand-dark/80 px-2.5 py-1 rounded border border-brand-gold/10">
                              <button
                                onClick={() => onUpdateQuantity(item.id, -1)}
                                className="text-brand-gold/60 hover:text-brand-gold p-0.5 cursor-pointer"
                              >
                                <Minus size={11} />
                              </button>
                              <span className="font-mono font-bold text-xs text-brand-beige/90 px-1 select-none">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => onUpdateQuantity(item.id, 1)}
                                className="text-brand-gold/60 hover:text-brand-gold p-0.5 cursor-pointer"
                              >
                                <Plus size={11} />
                              </button>
                            </div>

                            <span className="font-mono text-xs font-bold text-brand-gold">
                              {(singleItemPrice * item.quantity)} ฿
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-20 font-sans">
                  <div className="w-16 h-16 rounded-full bg-brand-gold/5 flex items-center justify-center text-brand-gold/50 mx-auto border border-brand-gold/10 mb-4 animate-bounce">
                    <ShoppingBag size={24} />
                  </div>
                  <p className="font-serif italic text-brand-beige/65 text-sm">{language === 'fr' ? "Votre panier d'achat est vide." : "Your shopping cart is empty."}</p>
                  <p className="text-[10px] text-brand-beige/35 mt-1">
                    {language === 'fr' ? "Sélectionnez des spécialités thaïlandaises uniques pour commencer." : "Select delicious home-cooked Thai dishes to get started."}
                  </p>
                </div>
              )}
            </div>

            {/* Bottom calculation ledgers & Checkout trigger footer */}
            {cartItems.length > 0 && (
              <div className="border-t border-brand-gold/15 bg-brand-dark/50 p-6 space-y-4">
                <div className="space-y-2 font-sans text-xs">
                  <div className="flex justify-between text-brand-beige/70">
                    <span>{language === 'fr' ? 'Sous-total' : 'Subtotal'}</span>
                    <span className="font-mono">{subtotal} ฿</span>
                  </div>
                  <div className="flex justify-between text-brand-beige/70">
                    <span>{language === 'fr' ? 'TVA Locale (7%)' : 'Local VAT (7%)'}</span>
                    <span className="font-mono">{vat} ฿</span>
                  </div>
                  {deliveryMode === 'delivery' && (
                    <div className="flex justify-between text-brand-beige/70">
                      <span>{language === 'fr' ? 'Rider / Livraison' : 'Rider / Delivery Fee'}</span>
                      <span className="font-mono">+{deliveryFee} ฿</span>
                    </div>
                  )}
                  <div className="border-t border-brand-gold/10 pt-2.5 flex justify-between text-brand-gold font-bold text-sm">
                    <span className="uppercase tracking-wider font-mono">{language === 'fr' ? 'Total de la table' : 'Total Price'}</span>
                    <span className="font-mono text-base">{total} ฿ <span className="text-[9px] text-[#F5E6C8]/40 font-normal">~{(total / 36).toFixed(1)}€</span></span>
                  </div>
                </div>

                <button
                  onClick={handleStartCheckout}
                  className="w-full flex items-center justify-center gap-3 bg-gradient-to-r from-brand-gold to-yellow-600 hover:from-yellow-600 hover:to-brand-gold text-brand-dark py-4 rounded-xl font-bold font-mono text-xs uppercase tracking-wider shadow-lg shadow-brand-gold/10 hover:shadow-brand-gold/30 transition-all cursor-pointer"
                >
                  <CreditCard size={15} />
                  {language === 'fr' ? 'Saisir mes Coordonnées' : 'Enter My Details'} ({total} ฿)
                </button>
              </div>
            )}
          </>
        )}

        {checkoutStep === 'form' && (
          /* 2. CHECKOUT ORDER FORM */
          <form onSubmit={handleConfirmOrder} className="flex-1 flex flex-col justify-between overflow-hidden">
            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-5">
              <span className="inline-block text-[10px] text-brand-gold font-mono uppercase tracking-[0.2em] bg-brand-gold/10 px-2 py-0.5 rounded border border-brand-gold/25">
                {language === 'fr' ? 'Étape 2 : Livraison & Facturation' : 'Step 2: Shipping & Details'}
              </span>

              {/* Personal Details */}
              <div className="space-y-4">
                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">{language === 'fr' ? 'Nom Complet' : 'Full Name'} *</label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Jean Dupont"
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    className="w-full bg-brand-dark border border-brand-gold/15 rounded-lg px-4 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">{language === 'fr' ? 'Téléphone direct' : 'Direct Mobile Phone'} *</label>
                  <input
                    type="tel"
                    required
                    placeholder="Ex: +33 6 12 34 56 78"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full bg-brand-dark border border-brand-gold/15 rounded-lg px-4 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold font-mono"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">Adresse E-mail</label>
                  <input
                    type="email"
                    placeholder="Ex: client@mail.com"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    className="w-full bg-brand-dark border border-brand-gold/15 rounded-lg px-4 py-2.5 text-xs text-brand-beige focus:outline-none focus:border-brand-gold"
                  />
                </div>

                {deliveryMode === 'delivery' && (
                  <div className="space-y-1">
                    <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">{language === 'fr' ? 'Adresse exacte à Bangkok' : 'Exact Address in Bangkok'} *</label>
                    <textarea
                      required
                      rows={2}
                      placeholder={language === 'fr' ? "Rue, hôtel, numéro de chambre ou point de repère à Bangkok (ex: Riverside Hotel, Apt 12b)" : "Street, hotel, room number, or landmark in Phra Nakhon (e.g., Riverside Hotel, Apt 12b)"}
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      className="w-full bg-brand-dark border border-brand-gold/15 rounded-lg p-3 text-xs text-brand-beige focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold"
                    />
                  </div>
                )}
              </div>

              {/* Payment Methods */}
              <div className="space-y-3 pt-2">
                <label className="block text-[10px] uppercase font-mono tracking-widest text-[#D4AF37]">{language === 'fr' ? 'Mode de Règlement Sécurisé' : 'Secure Payment Option'}</label>
                <div className="space-y-2.5">
                  <div 
                    onClick={() => setPaymentMethod('credit')}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === 'credit' 
                        ? 'border-brand-gold bg-brand-gold/5 text-brand-gold' 
                        : 'border-brand-gold/10 bg-brand-dark/30 text-brand-beige/60'
                    }`}
                  >
                    <span className="text-xs font-bold flex items-center gap-2">
                      <CreditCard size={14} />
                      {language === 'fr' ? 'Carte Bancaire (Simulée)' : 'Credit / Debit Card (Simulated)'}
                    </span>
                    <span className="w-2 h-2 rounded-full bg-current" />
                  </div>

                  <div 
                    onClick={() => setPaymentMethod('promptpay')}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === 'promptpay' 
                        ? 'border-brand-gold bg-brand-gold/5 text-brand-gold' 
                        : 'border-brand-gold/10 bg-brand-dark/30 text-brand-beige/60'
                    }`}
                  >
                    <span className="text-xs font-bold flex items-center gap-2">
                      <Truck size={14} />
                      {language === 'fr' ? 'PromptPay Thaï (QR Code)' : 'Thai PromptPay (QR Code)'}
                    </span>
                    <span className="w-2 h-2 rounded-full bg-current" />
                  </div>

                  <div 
                    onClick={() => setPaymentMethod('cash')}
                    className={`flex items-center justify-between p-3 rounded-xl border cursor-pointer transition-all ${
                      paymentMethod === 'cash' 
                        ? 'border-brand-gold bg-brand-gold/5 text-brand-gold' 
                        : 'border-brand-gold/10 bg-brand-dark/30 text-brand-beige/60'
                    }`}
                  >
                    <span className="text-xs font-bold flex items-center gap-2">
                      <Utensils size={14} />
                      {language === 'fr' ? 'Espèces à la livraison / retrait' : 'Pay Cash on collection'}
                    </span>
                    <span className="w-2 h-2 rounded-full bg-current" />
                  </div>
                </div>
              </div>

              {/* Simulated Credit Card Input Section */}
              {paymentMethod === 'credit' && (
                <div className="bg-brand-dark/95 border border-brand-gold/15 p-4 rounded-xl space-y-3">
                  <span className="text-[9px] font-mono uppercase text-brand-gold flex items-center gap-1.5 leading-none">
                    <ShieldCheck size={12} />
                    {language === 'fr' ? 'Transactions Cryptées SSL 256 bits' : 'SSL 256-Bit Encrypted Secure Connection'}
                  </span>
                  
                  <div className="space-y-1 mt-2">
                    <input
                      type="text"
                      maxLength={19}
                      placeholder={language === 'fr' ? "Numéro de carte (ex. 4000 1234 5678 9010)" : "Card number (e.g. 4000 1234 5678 9010)"}
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value.replace(/[^\d ]/g, ''))}
                      className="w-full bg-brand-charcoal text-xs p-2.5 rounded border border-brand-gold/10 focus:outline-none focus:border-brand-gold text-brand-beige font-mono"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <input
                      type="text"
                      maxLength={5}
                      placeholder="MM/AA"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      className="w-full bg-brand-charcoal text-xs p-2.5 rounded border border-brand-gold/10 focus:outline-none focus:border-brand-gold text-brand-beige font-mono text-center"
                    />
                    <input
                      type="password"
                      maxLength={3}
                      placeholder="CVC"
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value.replace(/\D/g, ''))}
                      className="w-full bg-brand-charcoal text-xs p-2.5 rounded border border-brand-gold/10 focus:outline-none focus:border-brand-gold text-brand-beige font-mono text-center"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Form submission controls at bottom */}
            <div className="border-t border-brand-gold/10 p-6 bg-brand-dark/40 flex gap-4">
              <button
                type="button"
                onClick={() => setCheckoutStep('cart')}
                className="w-1/3 py-3 border border-brand-gold/20 text-brand-beige rounded-lg text-xs font-mono uppercase tracking-wider cursor-pointer"
              >
                {language === 'fr' ? 'Retour' : 'Back'}
              </button>
              <button
                type="submit"
                className="w-2/3 py-3 bg-brand-gold text-brand-dark font-extrabold text-xs uppercase tracking-wider rounded-lg shadow-lg cursor-pointer"
              >
                {language === 'fr' ? "Confirmer l'Achat" : 'Confirm Order'} ({total} ฿)
              </button>
            </div>
          </form>
        )}

        {checkoutStep === 'tracking' && (
          /* 3. DYNAMIC MEAL PREP & TRACKER STEPPER */
          <div className="flex-1 flex flex-col justify-between px-6 py-4 overflow-y-auto space-y-6">
            <div className="text-center pt-6 space-y-2 font-sans">
              <div className="w-12 h-12 rounded-full bg-brand-green/10 border border-brand-green/30 text-brand-green flex items-center justify-center mx-auto animate-pulse">
                <CheckCircle size={24} />
              </div>
              <h3 className="font-serif text-xl font-bold text-brand-beige">{language === 'fr' ? 'Règlement Effectué !' : 'Order Placed!'}</h3>
              <p className="text-xs text-[#F5E6C8]/60 max-w-sm mx-auto">
                {language === 'fr' 
                  ? 'Votre transaction est validée de manière sécurisée. Notre brigade culinaire commence à chauffer les feux.' 
                  : 'Your payment was safely routed. Our family chefs are busy preparing your authentic delicious treat.'}
              </p>
              
              {/* Order code */}
              <div className="inline-block mt-3 bg-brand-dark px-4 py-2 border border-brand-gold/20 rounded-lg text-xs text-brand-gold font-mono tracking-widest font-black uppercase shadow-inner">
                {language === 'fr' ? 'CODE COMMANDE' : 'ORDER CODE'} : {currentOrderNumber}
              </div>
            </div>

            {/* Beautiful Interactive Stepper tracker */}
            <div className="bg-brand-dark/50 border border-brand-gold/10 rounded-2xl p-6 relative">
              <span className="text-[9px] font-mono uppercase text-brand-gold tracking-widest block mb-6 text-center">
                {language === 'fr' ? 'SUIVI COMMANDE EN DIRECT' : 'LIVE ORDER PROGRESS'}
              </span>

              {/* Horizontal / Vertical Stepper lines */}
              <div className="space-y-6 relative pl-8 border-l border-brand-gold/10 ml-2">
                {[
                  { 
                    step: 1, 
                    title_fr: 'Validation de commande', title_en: 'Order Confirmed', 
                    desc_fr: 'Accepté automatiquement par The Family.', desc_en: 'Cooking queue assigned.' 
                  },
                  { 
                    step: 2, 
                    title_fr: 'Woks en action (Cuisine)', title_en: 'Woks Sizzling (Kitchen)', 
                    desc_fr: 'Notre brigade saisit au wok herbes et ingrédients frais du matin.', desc_en: 'Chef firing up fresh bird\'s eye chili and Thai basil.' 
                  },
                  { 
                    step: 3, 
                    title_fr: 'Préparation et colisage', title_en: 'Packing & Sealing', 
                    desc_fr: 'Votre repas est soigneusement emballé dans des récipients isolés.', desc_en: 'Secured inside insulated thermal containers.' 
                  },
                  { 
                    step: 4, 
                    title_fr: 'Rider en itinéraire', title_en: 'Dispatched / Ready', 
                    desc_fr: 'Notre coursier personnel fonce vers votre localisation ou attend votre retrait.', desc_en: 'On its way to you or waiting happily for click & collect.' 
                  },
                ].map((item) => {
                  const isActive = trackingStep === item.step;
                  const isDone = trackingStep > item.step;

                  return (
                    <div key={item.step} className="relative font-sans">
                      {/* Circle Indicator on the absolute vertical line position */}
                      <div
                        className={`absolute -left-[41px] top-1 w-6 h-6 rounded-full border flex items-center justify-center text-[10px] font-mono font-bold transition-all ${
                          isDone
                            ? 'bg-brand-gold border-brand-gold text-brand-dark'
                            : isActive
                            ? 'bg-brand-dark border-brand-gold text-brand-gold animate-bounce'
                            : 'bg-brand-dark border-zinc-800 text-zinc-600'
                        }`}
                      >
                        {isDone ? '✔' : item.step}
                      </div>

                      {/* Text */}
                      <div className="text-left">
                        <div className="flex items-center justify-between">
                          <h4 className={`text-xs font-bold font-serif ${isActive ? 'text-brand-gold text-sm' : isDone ? 'text-brand-beige/80' : 'text-zinc-600'}`}>
                            {language === 'fr' ? item.title_fr : item.title_en}
                          </h4>
                          {isActive && (
                            <span className="flex items-center gap-1.5 text-[8px] font-mono text-brand-green bg-brand-green/10 border border-brand-green/20 px-2 py-0.5 rounded uppercase font-black animate-pulse">
                              <RefreshCw size={8} className="animate-spin" /> Live
                            </span>
                          )}
                        </div>
                        <p className={`text-[11px] mt-0.5 leading-relaxed ${isActive ? 'text-brand-beige/90' : 'text-zinc-500'}`}>
                          {language === 'fr' ? item.desc_fr : item.desc_en}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Visual simulated timing bar */}
              <div className="mt-8 pt-4 border-t border-brand-gold/5 flex justify-between items-center text-[10px] font-mono text-brand-beige/45">
                <span className="flex items-center gap-1.5">
                  <AlertCircle size={12} className="text-brand-gold" /> 
                  {language === 'fr' ? 'Actualisation toutes les 8s' : 'Refreshes every 8 seconds'}
                </span>
                <span>{language === 'fr' ? 'Arrivée : Env. 25-30 min' : 'ETA: Approx 20-25 mins'}</span>
              </div>
            </div>

            {/* Clear Order confirmation details / trigger start reset */}
            <div className="space-y-4">
              <div className="bg-brand-charcoal text-xs border border-brand-gold/10 p-4 rounded-xl">
                <div className="flex justify-between font-bold text-brand-beige pb-2 border-b border-brand-gold/5 font-serif">
                  <span>{language === 'fr' ? 'VOTRE TICKETING' : 'YOUR TICKETING'}</span>
                  <span>{total} ฿</span>
                </div>
                <div className="pt-2 text-[10px] text-zinc-400 space-y-1 font-mono uppercase">
                  <div>Client : {customerName}</div>
                  <div>Contact : {customerPhone}</div>
                  {deliveryMode === 'delivery' && <div className="leading-tight">{language === 'fr' ? 'Acheminement' : 'Destination'} : {deliveryAddress}</div>}
                  <div>{language === 'fr' ? 'Règlement' : 'Method'} : {paymentMethod === 'credit' ? (language === 'fr' ? 'Carte cryptée' : 'Crypto Card') : paymentMethod === 'promptpay' ? 'QR PromptPay' : (language === 'fr' ? 'Espèces' : 'Cash')}</div>
                </div>
              </div>

              <button
                type="button"
                onClick={handleResetCheckoutAndClear}
                className="w-full py-4 bg-brand-gold text-brand-dark font-extrabold text-xs uppercase tracking-widest rounded-xl shadow-lg border border-brand-gold cursor-pointer hover:bg-yellow-600 transition-colors"
              >
                {language === 'fr' ? 'Fermer & Retourner au menu principal' : 'Close & Return to Menu'}
              </button>
            </div>
          </div>
        )}
      </motion.div>
    </div>
  );
}
