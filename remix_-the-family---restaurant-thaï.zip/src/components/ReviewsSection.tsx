import React, { useState, useEffect } from 'react';
import { Star, MessageSquareCode, Check, Send, Sparkles } from 'lucide-react';
import { UserReview } from '../types';
import { INITIAL_REVIEWS } from '../data';
import { motion, AnimatePresence } from 'motion/react';
import { useLanguage } from '../context/LanguageContext';

export default function ReviewsSection() {
  const { t, language } = useLanguage();
  const [reviews, setReviews] = useState<UserReview[]>([]);
  const [newReview, setNewReview] = useState({ name: '', rating: 5, comment: '' });
  const [writeReviewOpen, setWriteReviewOpen] = useState(false);
  const [successMsg, setSuccessMsg] = useState(false);

  // Load reviews from localStorage or preset
  useEffect(() => {
    const saved = localStorage.getItem('the_family_reviews');
    if (saved) {
      try {
        setReviews(JSON.parse(saved));
      } catch (err) {
        setReviews(INITIAL_REVIEWS);
      }
    } else {
      setReviews(INITIAL_REVIEWS);
      localStorage.setItem('the_family_reviews', JSON.stringify(INITIAL_REVIEWS));
    }
  }, []);

  const handleRatingSelect = (val: number) => {
    setNewReview(prev => ({ ...prev, rating: val }));
  };

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newReview.name.trim() || !newReview.comment.trim()) return;

    const added: UserReview = {
      id: `custom-${Date.now()}`,
      name: newReview.name.trim(),
      rating: newReview.rating,
      comment: newReview.comment.trim(),
      date: new Date().toISOString().substring(0, 10),
      isVerified: true,
      helpfulCount: 0
    };

    const updated = [added, ...reviews];
    setReviews(updated);
    localStorage.setItem('the_family_reviews', JSON.stringify(updated));

    // Reset Form
    setNewReview({ name: '', rating: 5, comment: '' });
    setWriteReviewOpen(false);
    setSuccessMsg(true);
    setTimeout(() => setSuccessMsg(false), 3500);
  };

  const handleHelpfulClick = (id: string) => {
    const updated = reviews.map(r => {
      if (r.id === id) {
        return { ...r, helpfulCount: r.helpfulCount + 1 };
      }
      return r;
    });
    setReviews(updated);
    localStorage.setItem('the_family_reviews', JSON.stringify(updated));
  };

  return (
    <div className="space-y-12">
      {/* Testimonials summary and 'leave a review' trigger button */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 bg-brand-dark/50 border border-brand-gold/15 p-6 rounded-2xl">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-brand-gold/10 border border-brand-gold/25 flex items-center justify-center text-brand-gold shrink-0">
            <Star size={24} className="fill-brand-gold text-brand-gold" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-serif text-2xl font-black text-brand-beige">4.8</span>
              <span className="text-xs text-brand-beige/50">
                {language === 'fr' ? 'sur 5 étoiles' : 'out of 5 stars'}
              </span>
            </div>
            <p className="text-xs text-brand-gold/80 font-mono uppercase tracking-wider mt-0.5">
              {language === 'fr' 
                ? 'Recommandé par plus de 450 voyageurs internationaux' 
                : 'Recommended by over 450 global epicureans'}
            </p>
          </div>
        </div>

        <button
          onClick={() => setWriteReviewOpen(true)}
          className="bg-brand-gold text-brand-dark hover:bg-yellow-600 font-bold text-xs uppercase tracking-widest px-6 py-3.5 rounded-xl cursor-pointer transition-all shrink-0 flex items-center justify-center gap-2"
        >
          <MessageSquareCode size={14} />
          {t('reviews.btnSubmit') || (language === 'fr' ? 'Laisser un Avis' : 'Leave a Review')}
        </button>
      </div>

      {/* Success Notification Alert */}
      <AnimatePresence>
        {successMsg && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="p-4 bg-brand-green/10 border border-brand-green/30 text-brand-green rounded-xl text-xs flex items-center gap-2 font-sans"
          >
            <Check size={14} className="bg-brand-green text-white p-0.5 rounded-full" />
            <span>
              {language === 'fr' 
                ? 'Votre témoignage a été publié avec succès ! Merci de partager votre amour pour notre famille.' 
                : 'Your feedback has been published successfully! Thank you for sharing your love with our family.'}
            </span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Form Dialog Modal */}
      <AnimatePresence>
        {writeReviewOpen && (
          <div className="fixed inset-0 z-50 bg-brand-dark/95 backdrop-blur-sm flex items-center justify-center p-4">
            <div className="absolute inset-0" onClick={() => setWriteReviewOpen(false)} />
            <motion.div
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
              className="bg-brand-charcoal border border-brand-gold/30 rounded-2xl p-6 md:p-8 max-w-lg w-full relative z-10"
            >
              <div className="flex justify-between items-start mb-6">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-widest text-brand-gold">
                    {language === 'fr' ? "Témoignage d'Amour" : 'Love Letter'}
                  </span>
                  <h3 className="font-serif text-xl sm:text-2xl font-bold text-brand-beige">
                    {t('reviews.formTitle')}
                  </h3>
                </div>
                <button
                  onClick={() => setWriteReviewOpen(false)}
                  className="px-3 py-1 bg-brand-gold/10 border border-brand-gold/20 text-xs font-mono text-brand-gold rounded hover:bg-brand-gold hover:text-brand-dark cursor-pointer font-bold"
                >
                  {language === 'fr' ? 'Fermer' : 'Close'}
                </button>
              </div>

              <form onSubmit={handleSubmitReview} className="space-y-5">
                {/* Name */}
                <div className="space-y-1.5">
                  <label className="block text-xs uppercase tracking-widest font-mono text-brand-gold">
                    {language === 'fr' ? 'Nom / Prénom' : 'First & Last Name'}
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Ex: Sophie M."
                    value={newReview.name}
                    onChange={(e) => setNewReview(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full bg-brand-dark border border-brand-gold/15 rounded-lg px-4 py-3 text-xs sm:text-sm text-brand-beige focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold"
                  />
                </div>

                {/* Stars select */}
                <div className="space-y-1.5">
                  <label className="block text-xs uppercase tracking-widest font-mono text-brand-gold">
                    {t('reviews.ratingLabel')}
                  </label>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => handleRatingSelect(s)}
                        className="p-1 rounded text-brand-gold/50 hover:scale-110 transition-transform cursor-pointer"
                      >
                        <Star
                          size={24}
                          className={s <= newReview.rating ? 'fill-brand-gold text-brand-gold' : 'text-brand-beige/20'}
                        />
                      </button>
                    ))}
                    <span className="text-xs font-mono text-brand-gold font-bold self-center ml-2">
                      {newReview.rating} {language === 'fr' ? 'étoiles sur 5' : 'stars out of 5'}
                    </span>
                  </div>
                </div>

                {/* Comment area */}
                <div className="space-y-1.5">
                  <label className="block text-xs uppercase tracking-widest font-mono text-brand-gold">
                    {t('reviews.commentLabel')}
                  </label>
                  <textarea
                    required
                    rows={4}
                    placeholder={t('reviews.commentPlaceholder')}
                    value={newReview.comment}
                    onChange={(e) => setNewReview(prev => ({ ...prev, comment: e.target.value }))}
                    className="w-full bg-brand-dark border border-brand-gold/15 rounded-lg p-4 text-xs sm:text-sm text-brand-beige placeholder-brand-beige/30 focus:outline-none focus:border-brand-gold focus:ring-1 focus:ring-brand-gold"
                  />
                </div>

                {/* Submit action */}
                <button
                  type="submit"
                  className="w-full flex items-center justify-center gap-2 py-4 rounded-xl bg-brand-gold text-brand-dark font-extrabold text-xs uppercase tracking-wider shadow-lg hover:bg-yellow-600 transition-all cursor-pointer"
                >
                  <Send size={13} />
                  {language === 'fr' ? "Publier l'avis maintenant" : 'Publish review now'}
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Grid displaying the reviews */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {reviews.map((r) => (
          <div
            key={r.id}
            className="bg-brand-charcoal/45 border border-brand-gold/10 p-6 rounded-2xl flex flex-col justify-between hover:border-brand-gold/30 transition-all duration-300 relative group"
          >
            {/* Header stars */}
            <div>
              <div className="flex justify-between items-start mb-4">
                <div className="flex gap-0.5">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star
                      key={i}
                      size={13}
                      className={i < r.rating ? 'fill-brand-gold text-brand-gold' : 'text-brand-beige/10'}
                    />
                  ))}
                </div>
                <div className="flex items-center gap-1.5 self-start text-[8px] font-mono text-brand-green bg-brand-green/10 px-2 py-0.5 rounded border border-brand-green/20">
                  <span>✔ {t('reviews.verified') || (language === 'fr' ? 'VÉRIFIÉ' : 'VERIFIED')}</span>
                </div>
              </div>

              {/* Comment text */}
              <p className="font-serif text-sm italic text-brand-beige/90 leading-relaxed mb-6">
                "{r.comment}"
              </p>
            </div>

            {/* Guest identity & helpful trigger */}
            <div className="flex items-end justify-between pt-4 border-t border-brand-gold/5 mt-auto">
              <div>
                <h4 className="text-xs font-bold text-brand-beige font-sans">{r.name}</h4>
                <p className="text-[10px] font-mono text-[#F5E6C8]/40 mt-0.5">
                  {language === 'fr' ? 'Visité le' : 'Visited on'} {r.date}
                </p>
              </div>

              {/* Thank helpful button */}
              <button
                onClick={() => handleHelpfulClick(r.id)}
                className="text-[9px] font-mono text-brand-gold/60 hover:text-brand-gold flex items-center gap-1 px-2.5 py-1 rounded bg-brand-gold/5 border border-brand-gold/10 hover:border-brand-gold/25 transition-all cursor-pointer"
              >
                <span>{t('reviews.helpful') || (language === 'fr' ? 'Utile' : 'Helpful')} ({r.helpfulCount})</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
