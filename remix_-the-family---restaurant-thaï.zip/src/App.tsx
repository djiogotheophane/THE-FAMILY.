import React, { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import WhyUs from './components/WhyUs';
import SpecialtiesSection from './components/SpecialtiesSection';
import StorySection from './components/StorySection';
import MenuSection from './components/MenuSection';
import GallerySection from './components/GallerySection';
import MapContactSection from './components/MapContactSection';
import CartDrawer from './components/CartDrawer';
import DishDetailModal from './components/DishDetailModal';
import MenuChatWidget from './components/MenuChatWidget';
import FloatingActionsFAB from './components/FloatingActionsFAB';
import AtmosphereVideo from './components/AtmosphereVideo';
import { MenuItem, CartItem } from './types';
import { ArrowUp, Instagram, Facebook, Globe, Star, MapPin, Sparkles, Phone } from 'lucide-react';
import { AnimatePresence, motion } from 'motion/react';
import { useLanguage } from './context/LanguageContext';

export default function App() {
  const { t, language } = useLanguage();
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('hero');
  const [showScrollTop, setShowScrollTop] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);
  const [selectedDish, setSelectedDish] = useState<MenuItem | null>(null);

  // Track window scroll heights to highlight active section in Navbar header (scroll spy)
  useEffect(() => {
    const handleScroll = () => {
      // Show/hide scroll to top trigger
      setShowScrollTop(window.scrollY > 400);

      // Reading scroll progress tracker
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        setScrollProgress((window.scrollY / totalHeight) * 100);
      }

      const sections = ['hero', 'specialties', 'menu', 'history', 'gallery', 'reservation', 'contact'];
      const scrollPos = window.scrollY + 150; // trigger offset offset

      for (const sect of sections) {
        const el = document.getElementById(sect);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(sect);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleScrollToElement = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Add item logic: checks id + selectedOption choice
  const handleAddToCart = (item: MenuItem, selectedOption?: string) => {
    setCartItems((prevItems) => {
      const existingIdx = prevItems.findIndex(
        (i) => i.menuItem.id === item.id && i.selectedOption === selectedOption
      );

      if (existingIdx !== -1) {
        const updated = [...prevItems];
        updated[existingIdx].quantity += 1;
        return updated;
      } else {
        return [
          ...prevItems,
          {
            id: `${item.id}-${selectedOption || 'default'}`,
            menuItem: item,
            quantity: 1,
            selectedOption,
          },
        ];
      }
    });

    // Option: trigger cart drawer open immediately on add to delight user
    setIsCartOpen(true);
  };

  const handleUpdateQuantity = (id: string, amount: number) => {
    setCartItems((prevItems) =>
      prevItems
        .map((item) => {
          if (item.id === id) {
            return { ...item, quantity: item.quantity + amount };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const handleRemoveItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  const handleUpdateNotes = (id: string, notes: string) => {
    setCartItems((prev) =>
      prev.map((item) => (item.id === id ? { ...item, notes } : item))
    );
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const totalCartItemsCount = cartItems.reduce((acc, curr) => acc + curr.quantity, 0);

  return (
    <div className="relative min-h-screen bg-brand-dark flex flex-col justify-between selection:bg-brand-gold selection:text-brand-dark">
      
      {/* 0. DYNAMIC READING PROGRESS BAR */}
      <div 
        className="fixed top-0 left-0 h-[3px] bg-brand-gold z-[120] transition-all duration-75"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* 1. HEADER BAR */}
      <Header
        onOpenCart={() => setIsCartOpen(true)}
        cartCount={totalCartItemsCount}
        onScrollToElement={handleScrollToElement}
        activeSection={activeSection}
      />

      {/* 2. MAIN IMMERSIVE BODY FLOW */}
      <main className="flex-1 w-full relative">
        <Hero onScrollToElement={handleScrollToElement} />
        
        {/* Why Choose section */}
        <WhyUs />

        {/* Our Specialties Star Carousel / grid with click detail popup */}
        <SpecialtiesSection onAddToCart={handleAddToCart} onViewDish={setSelectedDish} />

        {/* Dynamic Storytelling Section */}
        <StorySection />

        {/* Cinematic Atmospheric Video Showcase */}
        <AtmosphereVideo />

        {/* Extended Menu Catalog */}
        <MenuSection onAddToCart={handleAddToCart} onViewDish={setSelectedDish} />

        {/* Filters/Photos Gallery Grid */}
        <GallerySection />

        {/* Location maps/Reviews grid */}
        <MapContactSection />
      </main>

      {/* 3. PREMIUM DEEP FOOTER */}
      <footer className="bg-brand-dark/95 border-t border-brand-gold/15 py-16 text-brand-beige">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12 font-sans text-xs">
            
            {/* Identity Column */}
            <div className="space-y-4">
              <span className="font-serif text-xl font-bold tracking-widest text-brand-gold italic">
                THE FAMILY
              </span>
              <p className="text-[#F5E6C8]/60 leading-relaxed mt-3">
                {language === 'fr' 
                  ? "L’authenticité et la noblesse des saveurs thaïes traditionnelles, préparées avec dévotion au cœur du quartier historique de Bangkok."
                  : "The true authenticity of traditional noble Thai flavors, prepared with devotion in the heart of Bangkok\'s historical sanctuary."}
              </p>
              <div className="flex gap-3 pt-2">
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-brand-gold/5 border border-brand-gold/20 text-brand-gold hover:bg-brand-gold hover:text-brand-dark rounded-full transition-colors cursor-pointer">
                  <Instagram size={14} />
                </a>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-brand-gold/5 border border-brand-gold/20 text-brand-gold hover:bg-brand-gold hover:text-brand-dark rounded-full transition-colors cursor-pointer">
                  <Facebook size={14} />
                </a>
                <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" className="p-2 bg-brand-gold/5 border border-brand-gold/20 text-brand-gold hover:bg-brand-gold hover:text-brand-dark rounded-full transition-colors cursor-pointer">
                  <Globe size={14} />
                </a>
              </div>
            </div>

            {/* Address Details Column */}
            <div className="space-y-4">
              <h4 className="font-serif font-bold text-sm tracking-wider uppercase text-brand-gold">
                {language === 'fr' ? 'Nous Trouver' : 'Find Us'}
              </h4>
              <div className="space-y-3 block text-brand-beige/70">
                <p className="flex items-start gap-2 leading-relaxed">
                  <MapPin size={15} className="text-brand-gold shrink-0 mt-0.5" />
                  <span>1/6 Prachathipatai Road, Phra Nakhon, Bangkok, {language === 'fr' ? 'Thaïlande' : 'Thailand'}</span>
                </p>
                <p className="flex items-center gap-2">
                  <Phone size={15} className="text-brand-gold" />
                  <a href="tel:+66958960395" className="hover:underline text-brand-gold font-mono font-bold">+66 95 896 0395</a>
                </p>
              </div>
            </div>

            {/* Shortcut Links Column */}
            <div className="space-y-4">
              <h4 className="font-serif font-bold text-sm tracking-wider uppercase text-brand-gold">
                {language === 'fr' ? 'Accès Rapides' : 'Quick Navigation'}
              </h4>
              <ul className="space-y-2 font-mono uppercase tracking-wider text-[11px] text-[#F5E6C8]/60">
                <li><button onClick={() => handleScrollToElement('hero')} className="hover:text-brand-gold transition-colors cursor-pointer">{language === 'fr' ? 'Accueil' : 'Home'}</button></li>
                <li><button onClick={() => handleScrollToElement('specialties')} className="hover:text-brand-gold transition-colors cursor-pointer">{language === 'fr' ? 'Nos Spécialités' : 'Specialties'}</button></li>
                <li><button onClick={() => handleScrollToElement('menu')} className="hover:text-brand-gold transition-colors cursor-pointer">{language === 'fr' ? 'Le Menu Complet' : 'Catalog Menu'}</button></li>
                <li><button onClick={() => handleScrollToElement('reservation')} className="hover:text-brand-gold transition-colors font-bold text-brand-gold cursor-pointer">{language === 'fr' ? 'Réserver une table' : 'Book a Table'}</button></li>
              </ul>
            </div>

            {/* Excellence Rating Column */}
            <div className="space-y-4">
              <h4 className="font-serif font-bold text-sm tracking-wider uppercase text-brand-gold">
                {language === 'fr' ? 'Excellence Certifiée' : 'Certified Excellence'}
              </h4>
              <div className="bg-brand-charcoal/80 border border-brand-gold/15 p-4 rounded-xl flex items-center gap-3">
                <Star size={24} className="fill-brand-gold text-brand-gold shrink-0" />
                <div>
                  <div className="flex items-center gap-1.5 font-bold">
                    <span className="text-sm">4.8 / 5.0</span>
                    <span className="text-[10px] text-zinc-500 font-normal">Trip Rating</span>
                  </div>
                  <p className="text-[9px] text-[#F5E6C8]/45 uppercase mt-0.5 tracking-wider font-mono">
                    {language === 'fr' ? 'Recommandé par des centaines de gourmets' : 'Endorsed by hundreds of genuine searchers'}
                  </p>
                </div>
              </div>
            </div>

          </div>

          {/* Copy statements */}
          <div className="border-t border-brand-gold/15 mt-12 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-center text-[10px] font-mono text-[#F5E6C8]/40 uppercase tracking-widest">
            <p>© {new Date().getFullYear()} THE FAMILY BANGKOK. {language === 'fr' ? 'Tous droits réservés.' : 'All rights reserved.'}</p>
            <div className="flex gap-4">
              <a href="#" className="hover:text-brand-gold">{language === 'fr' ? 'Mentions Légales' : 'Privacy & Terms'}</a>
              <span>•</span>
              <a href="#" className="hover:text-brand-gold">{language === 'fr' ? 'CGV de Commande' : 'Delivery Conditions'}</a>
            </div>
          </div>
        </div>
      </footer>

      {/* 4. ONLINE ORDERING CART SLIDEOUT DRAWER */}
      <AnimatePresence>
        {isCartOpen && (
          <CartDrawer
            isOpen={isCartOpen}
            onClose={() => setIsCartOpen(false)}
            cartItems={cartItems}
            onUpdateQuantity={handleUpdateQuantity}
            onRemoveItem={handleRemoveItem}
            onUpdateNotes={handleUpdateNotes}
            onClearCart={handleClearCart}
          />
        )}
      </AnimatePresence>

      {/* 5. FLOATING COMPANIONS AND QUICK ACTIONS (FAB & LIVE HELPR) */}
      <FloatingActionsFAB />
      <MenuChatWidget />

      {/* 6. IMMERSIVE DISH PAGE / MODAL OVERLAY */}
      <AnimatePresence>
        {selectedDish && (
          <DishDetailModal
            isOpen={!!selectedDish}
            onClose={() => setSelectedDish(null)}
            dish={selectedDish}
            onAddToCart={handleAddToCart}
          />
        )}
      </AnimatePresence>

    </div>
  );
}
